// Local multiplayer prototype: the SAME Room logic as the Cloudflare Durable Object, behind plain `ws`.
// Run: npm run dev:server        (PORT env var, default 8787)
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { WebSocketServer } from 'ws';
import { Room } from './roomLogic.js';
import { TICK_MS, MAX_MSG_BYTES } from '../shared/protocol.js';
import { sniffMedia, MEDIA_MAX_BYTES } from './mediaSniff.js';

export function createDevServer({ port = Number(process.env.PORT) || 8787, mediaDir } = {}) {
  mediaDir ??= fs.mkdtempSync(path.join(os.tmpdir(), 'osom-media-'));
  const rooms = new Map();
  const getRoom = (id) => {
    if (!rooms.has(id)) {
      const sockets = new Map();
      const room = new Room({
        id,
        send: (cid, msg) => { const w = sockets.get(cid); if (w && w.readyState === 1) w.send(JSON.stringify(msg)); },
        broadcast: (msg, except) => { const s = JSON.stringify(msg); for (const [cid, w] of sockets) if (cid !== except && w.readyState === 1) w.send(s); },
      });
      rooms.set(id, { room, sockets });
    }
    return rooms.get(id);
  };

  const server = http.createServer((req, res) => {
    const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'content-type,x-filename' };
    if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
    if (req.method === 'GET' && req.url === '/health') { res.writeHead(200, cors); return res.end('ok'); }

    if (req.method === 'POST' && req.url === '/api/upload') {          // media upload (MP3 / MP4 only, sniffed, size-capped)
      const chunks = []; let size = 0;
      req.on('data', (c) => { size += c.length; if (size > MEDIA_MAX_BYTES) { res.writeHead(413, cors); res.end('too big'); req.destroy(); } else chunks.push(c); });
      req.on('end', () => {
        if (res.writableEnded) return;
        const buf = Buffer.concat(chunks);
        const kind = sniffMedia(buf);
        if (!kind) { res.writeHead(415, cors); return res.end('unsupported'); }
        const id = crypto.randomUUID();
        fs.writeFileSync(path.join(mediaDir, id), buf);
        fs.writeFileSync(path.join(mediaDir, id + '.type'), kind.mime);
        res.writeHead(200, { ...cors, 'content-type': 'application/json' });
        res.end(JSON.stringify({ url: `/media/${id}`, kind: kind.kind, bytes: buf.length }));
      });
      return;
    }

    const m = req.method === 'GET' && /^\/media\/([a-f0-9-]{36})$/.exec(req.url);
    if (m) {                                                            // range requests so <video>/<audio> can seek
      const f = path.join(mediaDir, m[1]);
      if (!fs.existsSync(f)) { res.writeHead(404, cors); return res.end(); }
      const mime = fs.readFileSync(f + '.type', 'utf8'), total = fs.statSync(f).size;
      const range = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
      if (range) {
        const a = range[1] ? Number(range[1]) : 0, b = range[2] ? Math.min(Number(range[2]), total - 1) : total - 1;
        res.writeHead(206, { ...cors, 'content-type': mime, 'accept-ranges': 'bytes', 'content-range': `bytes ${a}-${b}/${total}`, 'content-length': b - a + 1 });
        return fs.createReadStream(f, { start: a, end: b }).pipe(res);
      }
      res.writeHead(200, { ...cors, 'content-type': mime, 'accept-ranges': 'bytes', 'content-length': total });
      return fs.createReadStream(f).pipe(res);
    }
    res.writeHead(404, cors); res.end();
  });

  const wss = new WebSocketServer({ noServer: true, maxPayload: MAX_MSG_BYTES });
  server.on('upgrade', (req, socket, head) => {
    const u = new URL(req.url, 'http://x');
    if (u.pathname !== '/ws') return socket.destroy();
    const roomId = (u.searchParams.get('room') || 'main').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 24) || 'main';
    wss.handleUpgrade(req, socket, head, (ws) => {
      const { room, sockets } = getRoom(roomId);
      const cid = crypto.randomUUID().slice(0, 8);
      sockets.set(cid, ws);
      let joined = false;
      ws.on('message', (data) => {
        let msg; try { msg = JSON.parse(data.toString()); } catch { return; }
        if (!joined) { joined = !!room.join(cid, msg); if (!joined) ws.close(); return; }
        room.handle(cid, msg);
      });
      ws.on('close', () => { sockets.delete(cid); room.leave(cid); });
      ws.on('error', () => {});
    });
  });

  const timers = [
    setInterval(() => rooms.forEach(({ room }) => room.tick()), TICK_MS),
    setInterval(() => rooms.forEach(({ room }) => room.tickTimers()), 250),
  ];
  return new Promise((resolve) => server.listen(port, () => resolve({
    port: server.address().port, rooms, mediaDir,
    close: () => new Promise((r) => { timers.forEach(clearInterval); wss.clients.forEach((c) => c.terminate()); server.close(() => r()); }),
  })));
}

if (import.meta.url === `file://${process.argv[1]}`) {
  createDevServer().then((s) => console.log(`dev server ws://localhost:${s.port}/ws?room=main  (media dir ${s.mediaDir})`));
}
