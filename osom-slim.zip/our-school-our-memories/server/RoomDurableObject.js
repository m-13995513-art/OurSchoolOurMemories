// Cloudflare Durable Object: one instance per room id. Wraps the platform-neutral Room logic.
// STATUS: written against the Workers API but NOT deployed or run (needs `wrangler` + a Cloudflare login).
import { Room } from './roomLogic.js';
import { TICK_MS, MAX_MSG_BYTES } from '../shared/protocol.js';

export class RoomDurableObject {
  constructor(state, env) {
    this.state = state; this.env = env;
    this.sockets = new Map();
    this.room = new Room({
      id: state.id.toString().slice(0, 8),
      send: (cid, msg) => { const w = this.sockets.get(cid); if (w) try { w.send(JSON.stringify(msg)); } catch {} },
      broadcast: (msg, except) => { const s = JSON.stringify(msg); for (const [cid, w] of this.sockets) if (cid !== except) try { w.send(s); } catch {} },
    });
    this.timer = null;
  }

  async fetch(request) {
    if (request.headers.get('Upgrade') !== 'websocket') return new Response('expected websocket', { status: 426 });
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    server.accept();
    const cid = crypto.randomUUID().slice(0, 8);
    this.sockets.set(cid, server);
    let joined = false;
    server.addEventListener('message', (ev) => {
      if (typeof ev.data !== 'string' || ev.data.length > MAX_MSG_BYTES) return;
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (!joined) { joined = !!this.room.join(cid, msg); if (!joined) server.close(1008, 'rejected'); return; }
      this.room.handle(cid, msg);
    });
    const gone = () => { this.sockets.delete(cid); this.room.leave(cid); if (!this.sockets.size && this.timer) { clearInterval(this.timer); this.timer = null; } };
    server.addEventListener('close', gone);
    server.addEventListener('error', gone);
    if (!this.timer) {
      let n = 0;
      this.timer = setInterval(() => { this.room.tick(); if (++n % 3 === 0) this.room.tickTimers(); }, TICK_MS);
    }
    return new Response(null, { status: 101, webSocket: client });
  }
}
