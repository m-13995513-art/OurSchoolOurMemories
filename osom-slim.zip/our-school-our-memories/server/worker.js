// Cloudflare Worker entry. STATUS: written, NOT deployed (see README "Deploy").
import { RoomDurableObject } from './RoomDurableObject.js';
import { sniffMedia, MEDIA_MAX_BYTES } from './mediaSniff.js';
export { RoomDurableObject };

const cors = (origin, env) => {
  const allow = (env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean);
  const ok = !allow.length || allow.includes(origin);
  return { 'Access-Control-Allow-Origin': ok ? (origin || '*') : 'null', 'Access-Control-Allow-Headers': 'content-type', 'Vary': 'Origin' };
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const headers = cors(request.headers.get('Origin') || '', env);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });

    if (url.pathname === '/ws') {
      const room = (url.searchParams.get('room') || 'main').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 24) || 'main';
      const stub = env.ROOMS.get(env.ROOMS.idFromName(room));
      return stub.fetch(request);
    }

    if (request.method === 'POST' && url.pathname === '/api/upload') {
      const len = Number(request.headers.get('content-length') || 0);
      if (!len || len > MEDIA_MAX_BYTES) return new Response('size', { status: 413, headers });
      const buf = Buffer.from(await request.arrayBuffer());
      const kind = sniffMedia(buf);
      if (!kind) return new Response('unsupported', { status: 415, headers });
      const id = crypto.randomUUID();
      await env.MEDIA.put(id, buf, { httpMetadata: { contentType: kind.mime }, customMetadata: { expires: String(Date.now() + 24 * 3600e3) } });
      return Response.json({ url: `/media/${id}`, kind: kind.kind, bytes: buf.length }, { headers });
    }

    const m = request.method === 'GET' && /^\/media\/([a-f0-9-]{36})$/.exec(url.pathname);
    if (m) {
      const range = request.headers.get('range');
      const obj = await env.MEDIA.get(m[1], range ? { range: request.headers } : undefined);
      if (!obj) return new Response('not found', { status: 404, headers });
      const h = new Headers(headers);
      obj.writeHttpMetadata(h); h.set('accept-ranges', 'bytes');
      return new Response(obj.body, { status: range ? 206 : 200, headers: h });
    }
    return new Response('OUR SCHOOL, OUR MEMORIES server', { headers });
  },
};
