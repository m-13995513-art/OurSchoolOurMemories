// Platform-neutral, server-authoritative room logic.
// Used by: server/RoomDurableObject.js (Cloudflare) and server/dev-server.js (local ws prototype).
// It never touches sockets itself: the host injects send(id,msg) / broadcast(msg,exceptId).

import {
  C2S, S2C, SCENES, LIMITS, MAX_PLAYERS, clamp, isNum, cleanText, validateMove, dataUrlOk,
} from '../shared/protocol.js';
import { AUDITORIUM } from '../src/maps/auditoriumMap.js';

export const RUN_SPEED = 190;            // px/s, must match src/config/settings.js
export const SIT_RANGE = 56;
export const COMPUTER_RANGE = 34;       // monitors are 50 px apart in the art, so each computer only answers to its own front
export const DOOR_RANGE = 28;
const HALF_W = 7, HALF_H = 3;            // feet collision box (matches the client)
const MSG_PER_SEC = 40;

// Which booth slot runs which app. NOT confirmed by the photos (see ASSETS.md) -> kept configurable.
export const COMPUTER_ASSIGNMENT = { AUDITORIUMC: 'computer_slot_1', MEDIA_PLAYER: 'computer_slot_2' };

const MAPS = {
  [SCENES.F1]: { collision: AUDITORIUM.collision, doors: AUDITORIUM.doors, w: AUDITORIUM.width, h: AUDITORIUM.height },
  [SCENES.F2]: { collision: AUDITORIUM.floor2.collision, doors: AUDITORIUM.floor2.doors, w: AUDITORIUM.floor2.width, h: AUDITORIUM.floor2.height },
};
const SEATS = new Map(AUDITORIUM.seats.map((s) => [s.id, s]));
const COMPUTERS = Object.fromEntries(AUDITORIUM.computers.map((c) => [c.id, c]));

export function isSolid(scene, x, y) {
  const m = MAPS[scene];
  if (!m) return true;
  if (x < HALF_W || y < HALF_H || x > m.w - HALF_W || y > m.h - HALF_H) return true;
  for (const [rx, ry, rw, rh] of m.collision) {
    if (x + HALF_W > rx && x - HALF_W < rx + rw && y + HALF_H > ry && y - HALF_H < ry + rh) return true;
  }
  return false;
}

export function standPointFor(seat) {
  for (let r = 18; r <= 140; r += 4) {
    for (let a = 0; a < 16; a++) {
      const ang = (a / 16) * Math.PI * 2;
      const x = seat.x + Math.cos(ang) * r, y = seat.y + Math.sin(ang) * r;
      if (!isSolid(SCENES.F1, x, y)) return { x, y };
    }
  }
  return { x: AUDITORIUM.spawn.x, y: AUDITORIUM.spawn.y };
}

const rid = () => [...crypto.getRandomValues(new Uint8Array(6))].map((b) => b.toString(16).padStart(2, '0')).join('');
const rnd = (n) => crypto.getRandomValues(new Uint32Array(1))[0] % n;

export class Room {
  constructor({ id = 'main', send, broadcast, now = () => Date.now() }) {
    this.id = id; this.send = send; this.broadcast = broadcast; this.now = now;
    this.players = new Map();               // connection id -> player
    this.byClient = new Map();              // stable clientId -> connection id
    this.occupied = new Map();              // seatId -> connection id
    this.dirty = new Set();
    this.parked = new Map();                // clientId -> last place of a player who dropped (kept 60 s for reconnects)
    this.slides = new Map();                // presentationId -> string[]
    this.ppt = { presentationId: null, title: '', totalSlides: 0, currentSlide: 0, isPlaying: false, ended: false, updatedAt: this.now(), controllerId: null };
    this.media = { items: [], index: 0, isPlaying: false, position: 0, positionAt: this.now(), volume: 0.8, updatedAt: this.now(), controllerId: null };
    this.files = [];                        // {id, kind, name, ownerKey, bytes, at}
    this.game = { type: null, phase: 'idle', updatedAt: this.now() };
    this._gameSecret = null;
  }

  // ---------------------------------------------------------------- connection lifecycle
  join(cid, hello) {
    if (!hello || hello.t !== C2S.HELLO) return this._err(cid, 'bad_hello');
    const clientId = cleanText(hello.clientId, 40) || rid();
    const old = this.byClient.get(clientId);
    let revived = null;
    if (old && this.players.has(old)) {       // reconnect: same browser, stale socket
      revived = this.players.get(old);
      this._drop(old, false);
    } else if (this.players.size >= MAX_PLAYERS) {
      return this._err(cid, 'room_full');
    } else if (this.parked.has(clientId)) {
      const k = this.parked.get(clientId);
      this.parked.delete(clientId);
      if (this.now() - k.at < 60_000) revived = k;
    }
    const spawn = AUDITORIUM.spawn;
    const p = {
      id: cid, clientId,
      nick: cleanText(hello.nick, LIMITS.nick) || 'Student',
      gender: hello.gender === 'female' ? 'female' : 'male',
      x: revived?.x ?? spawn.x, y: revived?.y ?? spawn.y, dir: revived?.dir ?? 'up', anim: revived?.anim ?? 'idle',
      scene: revived?.scene ?? SCENES.F1, seatId: null, lastMove: this.now(), win: { t: this.now(), n: 0 },
    };
    if (revived?.seatId && !this.occupied.has(revived.seatId)) { p.seatId = revived.seatId; this.occupied.set(p.seatId, cid); p.anim = 'sit'; }
    this.players.set(cid, p);
    this.byClient.set(clientId, cid);
    this.send(cid, {
      t: S2C.WELCOME, id: cid, clientId, room: this.id, resumed: !!revived,
      players: [...this.players.values()].map(this._pub),
      ppt: this.ppt, media: this.media, game: this._gamePublic(), files: this._filesFor(p), now: this.now(),
    });
    this.broadcast({ t: S2C.JOIN, p: this._pub(p) }, cid);
    return p;
  }

  leave(cid) { this._drop(cid, true); }

  _drop(cid, announce) {
    const p = this.players.get(cid);
    if (!p) return;
    if (p.seatId && this.occupied.get(p.seatId) === cid) this.occupied.delete(p.seatId);
    this.players.delete(cid);
    if (this.byClient.get(p.clientId) === cid) this.byClient.delete(p.clientId);
    this.dirty.delete(cid);
    for (const st of [this.ppt, this.media]) if (st.controllerId === cid) st.controllerId = null;
    if (announce) {
      this.parked.set(p.clientId, { x: p.x, y: p.y, dir: p.dir, scene: p.scene, at: this.now() });
      this.broadcast({ t: S2C.LEAVE, id: cid });
    }
  }

  // ---------------------------------------------------------------- inbound
  handle(cid, msg) {
    const p = this.players.get(cid);
    if (!p || !msg || typeof msg.t !== 'string') return;
    const nowT = this.now();
    if (nowT - p.win.t > 1000) p.win = { t: nowT, n: 0 };
    if (++p.win.n > MSG_PER_SEC) return;                      // flood guard
    switch (msg.t) {
      case C2S.MOVE: return this._move(p, msg);
      case C2S.INTERACT: return this._interact(p, msg);
      case C2S.SIT: return this._sit(p, msg);
      case C2S.STAND: return this._stand(p);
      case C2S.PPT: return this._ppt(p, msg);
      case C2S.MEDIA: return this._media(p, msg);
      case C2S.GAME: return this._gameCmd(p, msg);
      case C2S.ANSWER: return this._answer(p, msg);
      case C2S.GET_SLIDE: return this._getSlide(p, msg);
      case C2S.FILE_DELETE: return this._fileDelete(p, msg);
      case C2S.EMOTE: this.broadcast({ t: S2C.INTERACT, id: p.id, kind: 'emote', v: cleanText(msg.v, 8) }); return;
      case C2S.PING: this.send(cid, { t: S2C.PONG, c: msg.c, now: nowT }); return;
      default: return;
    }
  }

  _move(p, m) {
    if (!validateMove(m) || p.seatId) return;
    const t = this.now();
    const dt = clamp((t - p.lastMove) / 1000, 0.02, 1);
    p.lastMove = t;
    if (m.scene !== p.scene) return this._correct(p, 'scene');          // scene only changes through doors
    const dist = Math.hypot(m.x - p.x, m.y - p.y);
    if (dist > RUN_SPEED * dt * 1.35 + 14 || isSolid(p.scene, m.x, m.y)) return this._correct(p, 'move');
    p.x = m.x; p.y = m.y; p.dir = m.dir; p.anim = m.anim;
    this.dirty.add(p.id);
  }

  _correct(p, reason) { this.send(p.id, { t: S2C.CORRECT, x: p.x, y: p.y, dir: p.dir, scene: p.scene, reason }); }

  _interact(p, m) {
    const map = MAPS[p.scene];
    const door = map.doors.find((d) => d.id === m.id);
    if (!door || p.seatId) return;
    const [zx, zy, zw, zh] = door.zone;
    const near = p.x > zx - DOOR_RANGE && p.x < zx + zw + DOOR_RANGE && p.y > zy - DOOR_RANGE && p.y < zy + zh + DOOR_RANGE;
    if (!near) return this._correct(p, 'too_far');
    if (door.kind === 'exit') { this.send(p.id, { t: S2C.INTERACT, kind: 'exit_blocked', id: door.id }); return; }  // campus = NEEDS_REFERENCE
    const dest = door.to === 'auditorium_2f' ? SCENES.F2 : SCENES.F1;
    const sp = dest === SCENES.F2 ? AUDITORIUM.floor2.spawns[door.toSpawn] : AUDITORIUM.spawns[door.toSpawn];
    if (!sp) return;
    p.scene = dest; p.x = sp.x; p.y = sp.y; p.dir = sp.facing; p.anim = 'idle';
    this.send(p.id, { t: S2C.CORRECT, x: p.x, y: p.y, dir: p.dir, scene: p.scene, reason: 'door', door: door.id });
    this.dirty.add(p.id);
  }

  _sit(p, m) {
    const seat = SEATS.get(m.seatId);
    if (!seat || p.scene !== SCENES.F1) return;
    const holder = this.occupied.get(seat.id);
    if (holder && holder !== p.id) return this.send(p.id, { t: S2C.SEAT, ok: false, seatId: seat.id, why: 'taken' });
    const from = p.seatId ? SEATS.get(p.seatId) : p;
    if (Math.hypot(seat.x - from.x, seat.y - from.y) > SIT_RANGE) return this.send(p.id, { t: S2C.SEAT, ok: false, seatId: seat.id, why: 'far' });
    if (p.seatId) this.occupied.delete(p.seatId);
    this.occupied.set(seat.id, p.id);
    p.seatId = seat.id; p.x = seat.x; p.y = seat.y; p.dir = 'up'; p.anim = 'sit';
    this.dirty.add(p.id);
    this.send(p.id, { t: S2C.SEAT, ok: true, seatId: seat.id, x: p.x, y: p.y });
  }

  _stand(p) {
    if (!p.seatId) return;
    const seat = SEATS.get(p.seatId);
    this.occupied.delete(p.seatId); p.seatId = null;
    const sp = standPointFor(seat);
    p.x = sp.x; p.y = sp.y; p.anim = 'idle';
    this.dirty.add(p.id);
    this.send(p.id, { t: S2C.SEAT, ok: true, seatId: null, x: p.x, y: p.y });
  }

  // ---------------------------------------------------------------- computer permission
  _atComputer(p, app) {
    if (p.scene !== SCENES.F1 || p.seatId) return false;
    const c = COMPUTERS[COMPUTER_ASSIGNMENT[app]];
    return !!c && Math.hypot(p.x - c.x, p.y - c.y) <= COMPUTER_RANGE;
  }
  _lock(state, p) {                         // one controller at a time; takeover if the holder walked away / left
    if (state.controllerId && state.controllerId !== p.id) {
      const h = this.players.get(state.controllerId);
      if (h && this._atComputer(h, state === this.ppt ? 'AUDITORIUMC' : 'MEDIA_PLAYER')) return false;
    }
    state.controllerId = p.id;
    return true;
  }

  // ---------------------------------------------------------------- presentation (ONE state for all 4 screens)
  _ppt(p, m) {
    if (!this._atComputer(p, 'AUDITORIUMC')) return this._err(p.id, 'not_at_computer');
    if (!this._lock(this.ppt, p)) return this._err(p.id, 'computer_in_use');
    const s = this.ppt, t = this.now();
    switch (m.action) {
      case 'load': {
        const slides = Array.isArray(m.slides) ? m.slides : [];
        if (!slides.length || slides.length > LIMITS.slides) return this._err(p.id, 'slides_count');
        let total = 0;
        for (const u of slides) {
          if (!dataUrlOk(u) || u.length > LIMITS.slideBytes * 1.4) return this._err(p.id, 'slide_invalid');
          total += u.length;
        }
        if (total > LIMITS.totalSlideBytes * 1.4) return this._err(p.id, 'slides_too_big');
        if (s.presentationId) this.slides.delete(s.presentationId);
        const id = 'p_' + rid();
        this.slides.set(id, slides);
        Object.assign(s, { presentationId: id, title: cleanText(m.title, LIMITS.title) || 'Presentation', totalSlides: slides.length, currentSlide: 0, isPlaying: false, ended: false });
        this.files = this.files.filter((f) => !(f.kind === 'ppt' && f.ownerKey === p.clientId));
        this.files.push({ id, kind: 'ppt', name: s.title, ownerKey: p.clientId, bytes: total, at: t, slides: slides.length });
        this._broadcastFiles();
        break;
      }
      case 'open': {                                           // re-open one of the files listed in My Files
        const f = this.files.find((x) => x.id === m.id && x.kind === 'ppt');
        if (!f || !this.slides.has(f.id)) return this._err(p.id, 'no_such_file');
        Object.assign(s, { presentationId: f.id, title: f.name, totalSlides: f.slides, currentSlide: 0, isPlaying: false, ended: false });
        break;
      }
      case 'goto': if (!s.presentationId) return; s.currentSlide = clamp(Math.trunc(Number(m.index) || 0), 0, s.totalSlides - 1); s.ended = false; break;
      case 'next': if (!s.presentationId) return; if (s.currentSlide >= s.totalSlides - 1) { s.ended = true; s.isPlaying = false; } else s.currentSlide++; break;
      case 'prev': if (!s.presentationId) return; s.ended = false; s.currentSlide = Math.max(0, s.currentSlide - 1); break;
      case 'play': if (!s.presentationId) return; s.isPlaying = true; s.ended = false; break;
      case 'pause': s.isPlaying = false; break;
      case 'end': if (!s.presentationId) return; s.isPlaying = false; s.ended = true; break;
      case 'restart': if (!s.presentationId) return; Object.assign(s, { currentSlide: 0, ended: false, isPlaying: true }); break;
      case 'unload': if (s.presentationId && !this.files.some((f) => f.id === s.presentationId)) this.slides.delete(s.presentationId); Object.assign(s, { presentationId: null, title: '', totalSlides: 0, currentSlide: 0, isPlaying: false, ended: false }); break;
      case 'release': s.controllerId = null; break;
      default: return;
    }
    s.updatedAt = t;
    this.broadcast({ t: S2C.PPT, state: s });
  }

  _getSlide(p, m) {
    const arr = this.slides.get(m.presentationId);
    const i = Math.trunc(Number(m.index));
    if (!arr || !(i >= 0 && i < arr.length)) return;
    this.send(p.id, { t: S2C.SLIDE, presentationId: m.presentationId, index: i, data: arr[i] });
  }

  _fileDelete(p, m) {
    const f = this.files.find((x) => x.id === m.id);
    if (!f || f.ownerKey !== p.clientId) return this._err(p.id, 'not_yours');     // only your own uploads
    this.files = this.files.filter((x) => x !== f);
    this.slides.delete(f.id);
    if (this.ppt.presentationId === f.id) { Object.assign(this.ppt, { presentationId: null, title: '', totalSlides: 0, currentSlide: 0, isPlaying: false, ended: false, updatedAt: this.now() }); this.broadcast({ t: S2C.PPT, state: this.ppt }); }
    this.media.items = this.media.items.filter((i) => i.id !== f.id);
    this.media.index = clamp(this.media.index, 0, Math.max(0, this.media.items.length - 1));
    this._broadcastFiles();
    this.broadcast({ t: S2C.MEDIA, state: this.media });
  }

  // ---------------------------------------------------------------- media player (computer 2, fully separate state)
  _media(p, m) {
    if (!this._atComputer(p, 'MEDIA_PLAYER')) return this._err(p.id, 'not_at_computer');
    if (!this._lock(this.media, p)) return this._err(p.id, 'computer_in_use');
    const s = this.media, t = this.now();
    const cur = () => (s.isPlaying ? s.position + (t - s.positionAt) / 1000 : s.position);
    switch (m.action) {
      case 'add': {
        const it = m.item || {};
        if (!/^\/media\/[a-f0-9-]{8,64}$/.test(it.url || '') || !['audio', 'video'].includes(it.kind)) return this._err(p.id, 'bad_item');
        if (s.items.length >= LIMITS.mediaItems) return this._err(p.id, 'playlist_full');
        const item = { id: it.url.split('/').pop(), name: cleanText(it.name, LIMITS.title) || 'Untitled', kind: it.kind, url: it.url };
        s.items.push(item);
        this.files.push({ id: item.id, kind: 'media', name: item.name, ownerKey: p.clientId, bytes: Number(it.bytes) || 0, at: t });
        this._broadcastFiles();
        break;
      }
      case 'remove': s.items = s.items.filter((i) => i.id !== m.id); s.index = clamp(s.index, 0, Math.max(0, s.items.length - 1)); if (!s.items.length) { s.isPlaying = false; s.position = 0; } break;
      case 'play': if (!s.items.length) return; s.position = cur(); s.positionAt = t; s.isPlaying = true; break;
      case 'pause': s.position = cur(); s.positionAt = t; s.isPlaying = false; break;
      case 'stop': s.position = 0; s.positionAt = t; s.isPlaying = false; break;
      case 'seek': s.position = Math.max(0, Number(m.position) || 0); s.positionAt = t; break;
      case 'select': { const i = Math.trunc(Number(m.index)); if (!(i >= 0 && i < s.items.length)) return; s.index = i; s.position = 0; s.positionAt = t; s.isPlaying = m.autoplay !== false; break; }
      case 'next': if (!s.items.length) return; s.index = (s.index + 1) % s.items.length; s.position = 0; s.positionAt = t; break;
      case 'prev': if (!s.items.length) return; s.index = (s.index - 1 + s.items.length) % s.items.length; s.position = 0; s.positionAt = t; break;
      case 'volume': s.volume = clamp(Number(m.volume) || 0, 0, 1); break;
      case 'release': s.controllerId = null; break;
      default: return;
    }
    s.updatedAt = t;
    this.broadcast({ t: S2C.MEDIA, state: s });
  }

  // ---------------------------------------------------------------- mini games (state lives on the server)
  _gamePublic() {
    const g = this.game;
    if (g.type === 'quiz' || g.type === 'tf' || g.type === 'picture') {
      const q = g.questions?.[g.qIndex];
      const reveal = g.phase === 'reveal' || g.phase === 'done';
      return {
        type: g.type, phase: g.phase, qIndex: g.qIndex, total: g.questions?.length, startedAt: g.startedAt, deadline: g.deadline, seconds: g.seconds,
        question: q ? { q: q.q, options: q.options, image: q.image || null, correct: reveal ? q.correct : null } : null,
        answered: Object.keys(g.answers || {}).length, counts: reveal ? this._counts(g) : null,
        scores: this._leaderboard(g), updatedAt: g.updatedAt,
      };
    }
    if (g.type === 'wheel') return { type: 'wheel', phase: g.phase, entries: g.entries, spinId: g.spinId, startedAt: g.startedAt, duration: g.duration, resultIndex: g.phase === 'result' ? g.resultIndex : null, finalTurns: g.finalTurns, updatedAt: g.updatedAt };
    if (g.type === 'challenge') return { type: 'challenge', phase: g.phase, teams: g.teams, endsAt: g.endsAt, running: g.running, updatedAt: g.updatedAt };
    return { type: null, phase: 'idle', updatedAt: g.updatedAt };
  }
  _counts(g) { const c = Array((g.questions[g.qIndex].options || []).length).fill(0); for (const a of Object.values(g.answers)) c[a.choice]++; return c; }
  _leaderboard(g) {
    return Object.entries(g.scores || {}).map(([id, v]) => ({ id, nick: this.players.get(id)?.nick ?? v.nick, score: v.score })).sort((a, b) => b.score - a.score).slice(0, 10);
  }

  _gameCmd(p, m) {
    if (!this._atComputer(p, 'AUDITORIUMC')) return this._err(p.id, 'not_at_computer');
    if (!this._lock(this.ppt, p)) return this._err(p.id, 'computer_in_use');
    const g = this.game, t = this.now();
    const startQuiz = (type) => {
      const raw = Array.isArray(m.questions) ? m.questions.slice(0, 20) : [];
      const questions = raw.map((q) => ({
        q: cleanText(q.q, LIMITS.question),
        options: (type === 'tf' ? ['True', 'False'] : (q.options || []).slice(0, 4).map((o) => cleanText(o, LIMITS.option))),
        correct: Math.trunc(Number(q.correct)),
        image: type === 'picture' && dataUrlOk(q.image) && q.image.length < LIMITS.slideBytes * 1.4 ? q.image : null,
      })).filter((q) => q.q && q.options.length >= 2 && q.correct >= 0 && q.correct < q.options.length);
      if (!questions.length) return this._err(p.id, 'no_questions');
      this.game = { type, phase: 'question', questions, qIndex: 0, answers: {}, scores: {}, seconds: clamp(Number(m.seconds) || 20, 5, 120), updatedAt: t };
      this.game.startedAt = t; this.game.deadline = t + this.game.seconds * 1000;
    };
    switch (m.action) {
      case 'start': {
        if (['quiz', 'tf', 'picture'].includes(m.type)) startQuiz(m.type);
        else if (m.type === 'wheel') {
          const entries = (Array.isArray(m.entries) ? m.entries : []).slice(0, 16).map((e) => cleanText(e, 24)).filter(Boolean);
          if (entries.length < 2) return this._err(p.id, 'wheel_entries');
          this.game = { type: 'wheel', phase: 'ready', entries, spinId: 0, updatedAt: t };
        } else if (m.type === 'challenge') {
          const teams = (Array.isArray(m.teams) && m.teams.length ? m.teams : ['Team A', 'Team B', 'Team C', 'Team D']).slice(0, 6).map((n) => ({ name: cleanText(n, 16) || 'Team', score: 0 }));
          this.game = { type: 'challenge', phase: 'ready', teams, running: false, endsAt: null, seconds: clamp(Number(m.seconds) || 60, 10, 600), updatedAt: t };
        } else return;
        break;
      }
      case 'reveal': if (this.game.phase === 'question') this._reveal(); break;
      case 'next': if (this.game.phase === 'reveal') {
        if (g.qIndex + 1 >= g.questions.length) g.phase = 'done';
        else { g.qIndex++; g.phase = 'question'; g.answers = {}; g.startedAt = t; g.deadline = t + g.seconds * 1000; }
      } break;
      case 'spin': if (g.type === 'wheel' && g.phase !== 'spinning') {
        g.resultIndex = rnd(g.entries.length); g.spinId++; g.phase = 'spinning'; g.startedAt = t; g.duration = 4600; g.finalTurns = 5 + rnd(3);
      } break;
      case 'points': if (g.type === 'challenge') { const tm = g.teams[Math.trunc(Number(m.team))]; if (tm) tm.score = clamp(tm.score + clamp(Math.trunc(Number(m.delta) || 0), -50, 50), -999, 9999); } break;
      case 'timer': if (g.type === 'challenge') { g.running = !!m.run; g.endsAt = g.running ? t + g.seconds * 1000 : null; g.phase = g.running ? 'running' : 'ready'; } break;
      case 'stop': this.game = { type: null, phase: 'idle', updatedAt: t }; break;
      default: return;
    }
    this.game.updatedAt = t;
    this.broadcast({ t: S2C.GAME, state: this._gamePublic() });
  }

  _answer(p, m) {
    const g = this.game;
    if (!['quiz', 'tf', 'picture'].includes(g.type) || g.phase !== 'question' || this.now() > g.deadline + 400) return;
    const q = g.questions[g.qIndex], choice = Math.trunc(Number(m.choice));
    if (!(choice >= 0 && choice < q.options.length) || g.answers[p.id]) return;        // one answer per player
    g.answers[p.id] = { choice, at: this.now() };
    this.send(p.id, { t: S2C.GAME, ack: true, choice });
    this.broadcast({ t: S2C.GAME, state: this._gamePublic() });
    if (Object.keys(g.answers).length >= this.players.size) this._reveal();             // everyone answered
  }

  _reveal() {
    const g = this.game, q = g.questions[g.qIndex];
    for (const [id, a] of Object.entries(g.answers)) {
      const nick = this.players.get(id)?.nick ?? '?';
      g.scores[id] ??= { nick, score: 0 };
      if (a.choice === q.correct) {
        const left = clamp((g.deadline - a.at) / (g.seconds * 1000), 0, 1);
        g.scores[id].score += 100 + Math.round(50 * left);
      }
    }
    g.phase = 'reveal'; g.updatedAt = this.now();
    this.broadcast({ t: S2C.GAME, state: this._gamePublic() });
  }

  // called by the host every ~250 ms: timers that must advance without any player action
  tickTimers() {
    const g = this.game, t = this.now();
    for (const [k, v] of this.parked) if (t - v.at > 60_000) this.parked.delete(k);
    if (['quiz', 'tf', 'picture'].includes(g.type) && g.phase === 'question' && t > g.deadline) this._reveal();
    if (g.type === 'wheel' && g.phase === 'spinning' && t > g.startedAt + g.duration) { g.phase = 'result'; g.updatedAt = t; this.broadcast({ t: S2C.GAME, state: this._gamePublic() }); }
    if (g.type === 'challenge' && g.running && t > g.endsAt) { g.running = false; g.phase = 'ready'; g.updatedAt = t; this.broadcast({ t: S2C.GAME, state: this._gamePublic() }); }
  }

  // called at 10 Hz: only players that changed are sent
  tick() {
    if (!this.dirty.size) return;
    const list = [...this.dirty].map((id) => this.players.get(id)).filter(Boolean).map(this._pub);
    this.dirty.clear();
    if (list.length) this.broadcast({ t: S2C.SNAP, now: this.now(), p: list });
  }

  // ---------------------------------------------------------------- helpers
  _pub = (p) => ({ id: p.id, nick: p.nick, gender: p.gender, x: Math.round(p.x * 10) / 10, y: Math.round(p.y * 10) / 10, dir: p.dir, anim: p.anim, scene: p.scene, seat: p.seatId });
  // ownership is sent as a per-recipient boolean: clientId doubles as a reconnect credential and must never leave the server
  _filesFor(p) { return this.files.map((f) => ({ id: f.id, kind: f.kind, name: f.name, bytes: f.bytes, at: f.at, slides: f.slides, mine: f.ownerKey === p.clientId })); }
  _broadcastFiles() { for (const p of this.players.values()) this.send(p.id, { t: S2C.FILES, files: this._filesFor(p) }); }
  _err(id, code) { this.send(id, { t: S2C.ERROR, code }); }
}
