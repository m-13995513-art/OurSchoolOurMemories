// Verify uploads by their bytes, never by file name or the client's Content-Type.
export const MEDIA_MAX_BYTES = 80 * 1024 * 1024;

export function sniffMedia(buf) {
  if (!buf || buf.length < 12) return null;
  const isMp4 = buf.toString('latin1', 4, 8) === 'ftyp';
  if (isMp4) return { kind: 'video', mime: 'video/mp4' };
  const id3 = buf.toString('latin1', 0, 3) === 'ID3';
  const frame = buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0 && ((buf[1] >> 1) & 3) !== 0;   // MPEG audio frame sync
  if (id3 || frame) return { kind: 'audio', mime: 'audio/mpeg' };
  return null;
}
