import { defineConfig } from '@playwright/test';
// E2E drives the real Phaser build. BLOCKED in the authoring sandbox (no npm registry) — run locally with `npm i && npx playwright test`.
export default defineConfig({
  testDir: 'tests/e2e', timeout: 60000,
  use: { baseURL: 'http://localhost:5173', channel: 'chrome' },
  webServer: [
    { command: 'node server/dev-server.js', port: 8787, reuseExistingServer: true },
    { command: 'npx vite --port 5173', port: 5173, reuseExistingServer: true },
  ],
});
