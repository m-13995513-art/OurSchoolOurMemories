import Phaser from 'phaser';
import { GAME_W, GAME_H, FONT } from '../config/settings.js';
import { Save } from '../systems/Save.js';

export class PauseScene extends Phaser.Scene {
  constructor() { super('Pause'); }
  create() {
    this.add.rectangle(GAME_W / 2, GAME_H / 2, GAME_W, GAME_H, 0x000000, 0.6);
    this.add.text(GAME_W / 2, 200, 'PAUSED', { fontFamily: FONT, fontSize: '40px', color: '#fcd34d', stroke: '#1e3a8a', strokeThickness: 8 }).setOrigin(0.5);
    const mk = (y, label, fn) => this.add.text(GAME_W / 2, y, label, { fontFamily: FONT, fontSize: '18px', color: '#ffffff', backgroundColor: '#2563eb', padding: { x: 24, y: 12 } }).setOrigin(0.5).setInteractive({ useHandCursor: true }).on('pointerdown', fn);
    const resume = () => { this.scene.stop(); this.scene.resume('Auditorium'); };
    mk(320, 'RESUME', resume);
    const snd = mk(400, Save.load().muted ? 'SOUND: OFF' : 'SOUND: ON', () => { const m = !Save.load().muted; Save.patch({ muted: m }); snd.setText(m ? 'SOUND: OFF' : 'SOUND: ON'); this.game.events.emit('mute', m); });
    mk(480, 'MAIN MENU', () => { this.scene.stop(); this.scene.stop('Auditorium'); this.scene.start('MainMenu'); });
    this.input.keyboard.once('keydown-ESC', resume);
  }
}
