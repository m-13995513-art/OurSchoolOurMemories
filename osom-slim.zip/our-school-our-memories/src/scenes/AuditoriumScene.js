// Building 4 auditorium (1F + 2F), multiplayer, seats, doors, computers, 4 synced screens.
// Written against Phaser 3.90 but NOT RUN in the authoring sandbox (npm registry was blocked) — see README "Verification status".
import Phaser from 'phaser';
import { AUDITORIUM } from '../maps/auditoriumMap.js';
import { SCENES, C2S, S2C } from '../../shared/protocol.js';
import { WALK_SPEED, RUN_SPEED, SIT_RANGE, COMPUTER_RANGE, DOOR_RANGE, COMPUTER_ASSIGNMENT, isSolid, CAMERA_ZOOM, SEND_MS, SCENE_KEYS, FONT } from '../config/settings.js';
import { Character } from '../entities/Character.js';
import { NetworkClient } from '../network/NetworkClient.js';
import { RoomState } from '../network/RoomState.js';
import { MediaSync, httpBaseFromWs } from '../systems/MediaSync.js';
import { AudioSystem } from '../systems/AudioSystem.js';
import { Save } from '../systems/Save.js';
import { HUD } from '../ui/HUD.js';
import { AuditoriumC } from '../ui/AUDITORIUMC.js';
import { MediaPlayerUI } from '../ui/MediaPlayer.js';
import { GamePanel } from '../ui/GamePanel.js';
import { MobileControls } from '../ui/MobileControls.js';

const GUIDE = { x: 560, y: 820, lines: ['Welcome to our new auditorium!', 'The computer next to the exit opens AUDITORIUMC.', 'Sit in any seat, then use the arrow keys to hop to the next one.', 'The two doors beside the stage lead upstairs.'] };
const OVERHEAD_DEPTH = 100000;
const LOC = { auditorium: 'Building 4 · Auditorium 1F', auditorium_2f: 'Building 4 · Auditorium 2F' };

export class AuditoriumScene extends Phaser.Scene {
  constructor() { super('Auditorium'); }
  init(data) { this.profile = { ...Save.load(), ...data }; }

  create() {
    this.scene_ = SCENES.F1; this.seatId = null; this.sendAt = 0; this.lastSent = ''; this.others = new Map(); this.transition = false; this.guideLine = 0;
    this.audio = new AudioSystem(this.profile.muted);
    const unlock = () => this.audio.unlock();
    this.input.on('pointerdown', unlock); window.addEventListener('keydown', unlock, { once: true });
    this.game.events.on('mute', (m) => this.audio.setMuted(m));

    // ---- world
    this.floor = this.add.image(0, 0, 'floor1').setOrigin(0).setDepth(0);
    this.overhead = this.add.image(0, 0, 'overhead').setOrigin(0).setDepth(OVERHEAD_DEPTH);
    this.makeScreens();
    this.guide = new Character(this, { gender: this.profile.gender === 'male' ? 'female' : 'male', nick: 'Guide', x: GUIDE.x, y: GUIDE.y });
    this.guide.setPos(GUIDE.x, GUIDE.y); this.guide.play('right', 'idle');
    this.me = new Character(this, { gender: this.profile.gender, nick: this.profile.nick, x: AUDITORIUM.spawn.x, y: AUDITORIUM.spawn.y, me: true });
    this.me.setPos(AUDITORIUM.spawn.x, AUDITORIUM.spawn.y); this.me.play('up', 'idle');
    this.me.pos = { x: AUDITORIUM.spawn.x, y: AUDITORIUM.spawn.y };
    const cam = this.cameras.main; cam.setBounds(0, 0, AUDITORIUM.width, AUDITORIUM.height).setZoom(CAMERA_ZOOM).startFollow(this.me.sprite, true, 0.15, 0.15).fadeIn(400);

    // ---- input (global key capture off so typing in AUDITORIUMC fields never moves the player)
    const kb = this.input.keyboard; kb.disableGlobalCapture();
    this.keys = kb.addKeys('W,A,S,D,UP,DOWN,LEFT,RIGHT,SHIFT,E,SPACE,ESC,M,G', false);
    this.input.keyboard.on('keydown-E', () => this.interact()); this.input.keyboard.on('keydown-SPACE', () => this.interact());
    this.input.keyboard.on('keydown-ESC', () => this.pause());
    this.input.keyboard.on('keydown-M', () => { if (!this.typing()) { const m = !Save.load().muted; Save.patch({ muted: m }); this.audio.setMuted(m); this.hud.toast(m ? 'Sound off' : 'Sound on'); } });
    this.input.keyboard.on('keydown-G', () => { if (!this.typing()) { this.net.send({ t: C2S.EMOTE, v: 'Hi!' }); this.me.say('Hi!', 1800); } });
    for (const k of ['UP', 'DOWN', 'LEFT', 'RIGHT', 'W', 'A', 'S', 'D']) this.input.keyboard.on('keydown-' + k, () => this.seatedHop(k));

    // ---- network + UI
    this.net = new NetworkClient({ nick: this.profile.nick, gender: this.profile.gender });
    this.state = new RoomState(this.net);
    this.sync = new MediaSync(this.state, httpBaseFromWs(this.net.url));
    this.hud = new HUD({ nick: this.profile.nick, onAudio: () => { this.audio.unlock(); this.sync.enable(); this.hud.showAudioButton(false); }, onSettings: () => this.pause() });
    this.ac = new AuditoriumC(this.state); this.mp = new MediaPlayerUI(this.state, this.sync); this.panel = new GamePanel(this.state);
    this.mc = new MobileControls({ onInteract: () => this.interact() });
    this.hud.setLocation(LOC[SCENES.F1]);
    this.wireNetwork();
    this.net.connect();
    this.events.once('shutdown', () => this.cleanup());
    this.events.once('destroy', () => this.cleanup());
  }

  typing() { const a = document.activeElement; return !!a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName); }
  overlayOpen() { return [this.ac.root, this.mp.root].some((r) => r.isConnected && !r.hidden); }
  get blocked() { return this.transition || this.typing() || this.overlayOpen(); }

  // ------------------------------------------------------------------ screens (4 displays, ONE shared state)
  makeScreens() {
    this.screens = AUDITORIUM.screens.map((s) => {
      const [x, y, w, h] = s.rect, depth = s.layer === 'overhead' ? OVERHEAD_DEPTH + 1 : 2;
      const back = this.add.rectangle(x, y, w, h, 0x0b1220, 1).setOrigin(0).setDepth(depth);
      const img = this.add.image(x + w / 2, y + h / 2, '__DEFAULT').setDepth(depth + 0.1).setVisible(false);
      return { def: s, back, img, key: null };
    });
  }
  updateScreens() {
    const p = this.state.ppt, f1 = this.scene_ === SCENES.F1;
    const url = p.presentationId && !p.ended ? this.state.slide() : null;
    const key = url ? `slide:${p.presentationId}:${p.currentSlide}` : null;
    for (const s of this.screens) {
      s.back.setVisible(f1); s.key = key;
      if (!key || !f1) { s.img.setVisible(false); continue; }
      const apply = () => { if (s.key !== key) return; s.img.setTexture(key).setDisplaySize(s.def.rect[2], s.def.rect[3]).setVisible(true); };
      if (this.textures.exists(key)) apply();
      else { const im = new Image(); im.onload = () => { if (!this.textures.exists(key)) this.textures.addImage(key, im); apply(); }; im.src = url; }
    }
  }

  // ------------------------------------------------------------------ network
  wireNetwork() {
    const net = this.net, st = this.state;
    net.on('status', () => this.hud.setConnection(net.status, st.players.size));
    net.on(S2C.WELCOME, (m) => {
      const me = m.players.find((p) => p.id === m.id); if (!me) return;
      this.audio.hello();
      this.applyScene(me.scene); this.place(me.x, me.y, me.dir);
      if (me.seat) this.seatId = me.seat;
    });
    net.on(S2C.CORRECT, (m) => {
      if (m.reason === 'door') { this.audio.door(); this.doorTransition(m); return; }
      if (m.scene !== this.scene_) this.applyScene(m.scene);
      this.place(m.x, m.y, m.dir);
    });
    net.on(S2C.SEAT, (m) => {
      if (!m.ok) { this.audio.deny(); this.hud.toast(m.why === 'taken' ? 'That seat is taken' : 'Too far from that seat'); return; }
      this.audio.sit(); this.seatId = m.seatId; this.place(m.x, m.y, 'up');
      this.me.play('up', m.seatId ? 'sit' : 'idle'); this.lastSent = '';
    });
    net.on(S2C.INTERACT, (m) => {
      if (m.kind === 'exit_blocked') this.hud.toast('The school map is not built yet — it needs reference photos (NEEDS_REFERENCE).', 4200);
      if (m.kind === 'emote') { const o = this.others.get(m.id); o?.say(m.v || 'Hi!', 1800); }
    });
    st.subscribe((kind) => {
      if (kind === 'snap' || kind === 'players' || kind === 'welcome') { this.syncOthers(); this.hud.setConnection(net.status, st.players.size); this.hud.setPlayers([...st.players.values()], net.id); }
      if (kind === 'ppt' || kind === 'slide' || kind === 'welcome') this.updateScreens();
      if (kind === 'media' || kind === 'welcome') this.hud.showAudioButton(st.media.isPlaying && !this.sync.enabled);
    });
  }
  place(x, y, dir = 'up') { this.me.pos = { x, y }; this.me.setPos(x, y); this.me.play(dir, this.seatId ? 'sit' : 'idle'); }
  applyScene(scene) {
    if (scene === this.scene_) return;
    this.scene_ = scene; this.floor.setTexture(SCENE_KEYS[scene]);
    this.overhead.setVisible(scene === SCENES.F1); this.guide.setVisible(scene === SCENES.F1);
    this.hud.setLocation(LOC[scene]); this.updateScreens(); this.syncOthers();
  }
  doorTransition(m) {
    this.transition = true; const cam = this.cameras.main;
    cam.fadeOut(220, 16, 26, 51);
    cam.once('camerafadeoutcomplete', () => { this.applyScene(m.scene); this.place(m.x, m.y, m.dir); cam.fadeIn(260, 16, 26, 51); cam.once('camerafadeincomplete', () => (this.transition = false)); });
  }
  syncOthers() {
    const live = new Set();
    for (const p of this.state.players.values()) {
      if (p.id === this.net.id) continue;
      live.add(p.id);
      let o = this.others.get(p.id);
      if (!o) { o = new Character(this, { gender: p.gender, nick: p.nick, x: p.x, y: p.y }); o.setPos(p.x, p.y); this.others.set(p.id, o); }
      o.target = p; o.setVisible(p.scene === this.scene_);
    }
    for (const [id, o] of this.others) if (!live.has(id)) { o.destroy(); this.others.delete(id); }
  }

  // ------------------------------------------------------------------ interaction
  candidates() {
    const me = this.me.pos, out = [];
    const near = (a, b, r) => Math.hypot(a.x - b.x, a.y - b.y) <= r;
    if (this.seatId) return [{ kind: 'stand', text: 'Stand up' }];
    if (this.scene_ === SCENES.F1) {
      for (const c of AUDITORIUM.computers) if (near(me, c, COMPUTER_RANGE)) {
        const app = Object.keys(COMPUTER_ASSIGNMENT).find((k) => COMPUTER_ASSIGNMENT[k] === c.id);
        out.push({ kind: 'computer', app, text: app === 'MEDIA_PLAYER' ? 'Open Media Player' : 'Open AUDITORIUMC', d: 0 });
      }
    }
    const doors = this.scene_ === SCENES.F1 ? AUDITORIUM.doors : AUDITORIUM.floor2.doors;
    for (const d of doors) { const [x, y, w, h] = d.zone; if (me.x > x - DOOR_RANGE && me.x < x + w + DOOR_RANGE && me.y > y - DOOR_RANGE && me.y < y + h + DOOR_RANGE) out.push({ kind: 'door', id: d.id, text: d.kind === 'exit' ? 'Exit (school map)' : d.kind === 'stairs_up' ? 'Go upstairs' : 'Go downstairs', d: 5 }); }
    if (this.scene_ === SCENES.F1) {
      if (near(me, GUIDE, 44)) out.push({ kind: 'guide', text: 'Talk to Guide', d: 8 });
      const taken = new Set([...this.state.players.values()].map((p) => p.seat).filter(Boolean));
      let best = null, bd = SIT_RANGE;
      for (const s of AUDITORIUM.seats) { if (taken.has(s.id)) continue; const d = Math.hypot(s.x - me.x, s.y - me.y); if (d < bd) { bd = d; best = s; } }
      if (best) out.push({ kind: 'sit', seat: best, text: 'Sit down', d: 10 + bd / 100 });
    }
    return out.sort((a, b) => a.d - b.d);
  }
  interact() {
    if (this.blocked || !this.me) return;
    const c = this.candidates()[0]; if (!c) return;
    this.audio.unlock(); this.audio.click();
    if (c.kind === 'stand') this.net.send({ t: C2S.STAND });
    else if (c.kind === 'sit') { this.me.play(this.me.dir, 'interact'); this.net.send({ t: C2S.SIT, seatId: c.seat.id }); }
    else if (c.kind === 'door') this.net.send({ t: C2S.INTERACT, id: c.id });
    else if (c.kind === 'computer') { this.net.open ? (c.app === 'MEDIA_PLAYER' ? this.mp.open() : this.ac.open()) : this.hud.toast('Not connected to the server — start it with npm run dev:server'); }
    else if (c.kind === 'guide') { this.guide.say(GUIDE.lines[this.guideLine++ % GUIDE.lines.length], 3600); }
  }
  seatedHop(k) {
    if (!this.seatId || this.blocked) return;
    const v = { UP: [0, -1], W: [0, -1], DOWN: [0, 1], S: [0, 1], LEFT: [-1, 0], A: [-1, 0], RIGHT: [1, 0], D: [1, 0] }[k];
    const cur = AUDITORIUM.seats.find((s) => s.id === this.seatId); if (!cur) return;
    const taken = new Set([...this.state.players.values()].map((p) => p.seat).filter(Boolean));
    let best = null, bs = 1e9;
    for (const s of AUDITORIUM.seats) {
      if (s.id === cur.id || taken.has(s.id)) continue;
      const dx = s.x - cur.x, dy = s.y - cur.y, along = dx * v[0] + dy * v[1], side = Math.abs(dx * v[1] - dy * v[0]);
      if (along <= 0 || Math.hypot(dx, dy) > SIT_RANGE - 4 || side > along) continue;
      const score = along + side * 2; if (score < bs) { bs = score; best = s; }
    }
    if (best) this.net.send({ t: C2S.SIT, seatId: best.id });
  }
  pause() { if (this.typing() || this.overlayOpen() || this.scene.isPaused()) return; this.scene.launch('Pause'); this.scene.pause(); }

  // ------------------------------------------------------------------ frame loop
  update(time, delta) {
    const dt = Math.min(delta, 50) / 1000, me = this.me; if (!me) return;
    let vx = 0, vy = 0, run = false;
    if (!this.blocked && !this.seatId) {
      const k = this.keys; vx = (k.D.isDown || k.RIGHT.isDown ? 1 : 0) - (k.A.isDown || k.LEFT.isDown ? 1 : 0); vy = (k.S.isDown || k.DOWN.isDown ? 1 : 0) - (k.W.isDown || k.UP.isDown ? 1 : 0);
      run = k.SHIFT.isDown;
      if (!vx && !vy) { vx = this.mc.vector.x; vy = this.mc.vector.y; run = run || this.mc.run; }
    }
    const len = Math.hypot(vx, vy);
    let anim = this.seatId ? 'sit' : 'idle', dir = me.dir;
    if (len > 0.01 && !this.seatId) {
      const mag = Math.min(1, len), sp = (run ? RUN_SPEED : WALK_SPEED) * (this.mc.vector.x || this.mc.vector.y ? mag : 1);
      const nx = this.me.pos.x + (vx / len) * sp * dt, ny = this.me.pos.y + (vy / len) * sp * dt;
      let { x, y } = this.me.pos;
      if (!isSolid(this.scene_, nx, y)) x = nx;           // axis-separated collision => sliding along walls
      if (!isSolid(this.scene_, x, ny)) y = ny;
      const moved = x !== this.me.pos.x || y !== this.me.pos.y;
      dir = Math.abs(vx) > Math.abs(vy) ? (vx > 0 ? 'right' : 'left') : (vy > 0 ? 'down' : 'up');
      if (moved) { anim = run ? 'run' : 'walk'; this.me.pos = { x, y }; this.audio.step(run); }
    }
    if (me.anim !== 'interact' || anim !== 'idle') me.play(dir, anim);
    me.setPos(this.me.pos.x, this.me.pos.y);

    if (this.net.open && time >= this.sendAt && !this.seatId) {
      const sig = `${Math.round(this.me.pos.x)},${Math.round(this.me.pos.y)},${dir},${anim},${this.scene_}`;
      if (sig !== this.lastSent) { this.net.send({ t: C2S.MOVE, x: this.me.pos.x, y: this.me.pos.y, dir, anim, scene: this.scene_ }, true); this.lastSent = sig; }
      this.sendAt = time + SEND_MS;
    }
    // other players: smooth toward the 10 Hz server snapshots
    for (const o of this.others.values()) {
      const t = o.target; if (!t) continue;
      const k = 1 - Math.pow(0.0005, dt), nx = o.x + (t.x - o.x) * k, ny = o.y + (t.y - o.y) * k;
      o.setPos(Math.abs(t.x - nx) < 0.3 ? t.x : nx, Math.abs(t.y - ny) < 0.3 ? t.y : ny); o.play(t.dir, t.seat ? 'sit' : t.anim);
    }
    const c = this.blocked ? null : this.candidates()[0];
    this.hud.setPrompt(c ? c.text : '', this.mc.root && getComputedStyle(this.mc.root).display !== 'none' ? 'A' : 'E');
  }

  cleanup() {
    if (this.cleaned) return; this.cleaned = true;
    this.game.events.off('mute');
    this.net?.close(); this.sync?.destroy(); this.hud?.destroy(); this.ac?.root.remove(); this.mp?.root.remove(); this.panel?.root.remove(); this.mc?.destroy();
  }
}
