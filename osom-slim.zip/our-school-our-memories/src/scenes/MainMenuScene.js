import Phaser from 'phaser';
import { GAME_W, GAME_H, COLORS, FONT } from '../config/settings.js';
import { Save } from '../systems/Save.js';

export class MainMenuScene extends Phaser.Scene {
  constructor() { super('MainMenu'); }
  create() {
    const bg = this.add.image(GAME_W / 2, GAME_H / 2, 'floor1').setScale(1.1);
    this.tweens.add({ targets: bg, x: GAME_W / 2 + 40, y: GAME_H / 2 + 25, duration: 14000, yoyo: true, repeat: -1, ease: 'Sine.inOut' });
    this.add.rectangle(GAME_W / 2, GAME_H / 2, GAME_W, GAME_H, COLORS.navy, 0.62);
    // drifting dust motes for a little life
    for (let i = 0; i < 26; i++) {
      const p = this.add.rectangle(Phaser.Math.Between(0, GAME_W), Phaser.Math.Between(0, GAME_H), 3, 3, 0xfff8e7, 0.5);
      this.tweens.add({ targets: p, y: p.y - Phaser.Math.Between(60, 200), alpha: 0, duration: Phaser.Math.Between(3000, 7000), repeat: -1, delay: Phaser.Math.Between(0, 4000) });
    }
    const t1 = this.add.text(GAME_W / 2, 150, 'OUR SCHOOL,', { fontFamily: FONT, fontSize: '46px', color: '#fff8e7', stroke: '#1e3a8a', strokeThickness: 10 }).setOrigin(0.5);
    const t2 = this.add.text(GAME_W / 2, 220, 'OUR MEMORIES', { fontFamily: FONT, fontSize: '46px', color: '#fcd34d', stroke: '#1e3a8a', strokeThickness: 10 }).setOrigin(0.5);
    this.tweens.add({ targets: [t1, t2], y: '+=6', duration: 1800, yoyo: true, repeat: -1, ease: 'Sine.inOut' });
    this.add.text(GAME_W / 2, 280, 'SJK(C) JENJAROM · NEW AUDITORIUM', { fontFamily: FONT, fontSize: '12px', color: '#bae6fd' }).setOrigin(0.5);

    const save = Save.load();
    this.btn(GAME_W / 2, 400, 'START', () => this.scene.start('CharacterSelect'), true);
    this.btn(GAME_W / 2, 470, save.muted ? 'SOUND: OFF' : 'SOUND: ON', (b) => { const m = !Save.load().muted; Save.patch({ muted: m }); b.setText(m ? 'SOUND: OFF' : 'SOUND: ON'); });
    this.btn(GAME_W / 2, 540, 'CONTROLS', () => this.help());
    this.add.text(GAME_W / 2, GAME_H - 28, 'Made with love for our school · multiplayer needs the game server running', { fontFamily: FONT, fontSize: '8px', color: '#93c5fd' }).setOrigin(0.5);
    this.input.keyboard.once('keydown-ENTER', () => this.scene.start('CharacterSelect'));
  }
  btn(x, y, label, fn, primary = false) {
    const t = this.add.text(x, y, label, { fontFamily: FONT, fontSize: primary ? '22px' : '15px', color: primary ? '#101a33' : '#ffffff', backgroundColor: primary ? '#fcd34d' : '#2563eb', padding: { x: 28, y: 14 } }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    t.on('pointerover', () => t.setScale(1.06)); t.on('pointerout', () => t.setScale(1));
    t.on('pointerdown', () => fn(t));
    return t;
  }
  help() {
    const g = this.add.container(0, 0).setDepth(50);
    const panel = this.add.rectangle(GAME_W / 2, GAME_H / 2, 760, 420, 0x101a33, 0.96).setStrokeStyle(4, 0xfcd34d).setInteractive();
    const txt = this.add.text(GAME_W / 2, GAME_H / 2 - 20, 'WASD / ARROWS   move\nSHIFT            run\nE / SPACE        interact · sit · stand · doors · computers\nESC              pause\nM                sound on/off\n\nPHONE / TABLET: left stick = move, RUN, A = interact\n\nWalk to the computer by the exit door to open AUDITORIUMC.', { fontFamily: FONT, fontSize: '11px', color: '#ffffff', lineSpacing: 12, align: 'left' }).setOrigin(0.5);
    const x = this.add.text(GAME_W / 2, GAME_H / 2 + 175, 'CLOSE', { fontFamily: FONT, fontSize: '14px', color: '#101a33', backgroundColor: '#fcd34d', padding: { x: 18, y: 10 } }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    g.add([panel, txt, x]); x.on('pointerdown', () => g.destroy());
  }
}
