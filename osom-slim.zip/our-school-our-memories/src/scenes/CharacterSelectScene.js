import Phaser from 'phaser';
import { GAME_W, GAME_H, COLORS, FONT } from '../config/settings.js';
import { Save } from '../systems/Save.js';

export class CharacterSelectScene extends Phaser.Scene {
  constructor() { super('CharacterSelect'); }
  create() {
    const save = Save.load(); this.gender = save.gender;
    this.add.rectangle(GAME_W / 2, GAME_H / 2, GAME_W, GAME_H, COLORS.navy);
    this.add.image(GAME_W / 2, GAME_H / 2, 'floor1').setAlpha(0.18).setScale(1.1);
    this.add.text(GAME_W / 2, 70, 'CHOOSE YOUR CHARACTER', { fontFamily: FONT, fontSize: '26px', color: '#fcd34d', stroke: '#1e3a8a', strokeThickness: 6 }).setOrigin(0.5);

    this.cards = {};
    [['male', GAME_W / 2 - 190], ['female', GAME_W / 2 + 190]].forEach(([g, x]) => {
      const card = this.add.rectangle(x, 330, 300, 380, 0x1e3a8a, 0.85).setStrokeStyle(5, 0x93c5fd).setInteractive({ useHandCursor: true });
      const spr = this.add.sprite(x, 440, g, 'front_idle_0').setOrigin(0.5, 0.95).setScale(2.4);
      spr.play(`${g}_front_walk`);
      this.add.text(x, 180, g === 'male' ? 'BOY' : 'GIRL', { fontFamily: FONT, fontSize: '18px', color: '#ffffff' }).setOrigin(0.5);
      card.on('pointerdown', () => this.pick(g));
      this.cards[g] = { card, spr };
    });
    this.pick(this.gender);

    // nickname field (real DOM input => mobile keyboards just work)
    this.input_ = document.createElement('input');
    Object.assign(this.input_, { type: 'text', maxLength: 16, placeholder: 'Your nickname', value: save.nick, autocomplete: 'off' });
    Object.assign(this.input_.style, { position: 'fixed', left: '50%', top: '80%', transform: 'translate(-50%,-50%)', width: 'min(320px,70vw)', padding: '12px 16px', fontSize: '18px', borderRadius: '12px', border: '3px solid #fcd34d', background: '#fff8e7', color: '#101a33', textAlign: 'center', fontFamily: 'system-ui, sans-serif', fontWeight: 700, zIndex: 20 });
    document.body.append(this.input_);

    const go = this.add.text(GAME_W / 2, GAME_H - 52, 'ENTER AUDITORIUM ▶', { fontFamily: FONT, fontSize: '20px', color: '#101a33', backgroundColor: '#fcd34d', padding: { x: 26, y: 13 } }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    go.on('pointerdown', () => this.start());
    const back = this.add.text(30, 30, '◀ BACK', { fontFamily: FONT, fontSize: '12px', color: '#ffffff' }).setInteractive({ useHandCursor: true });
    back.on('pointerdown', () => this.scene.start('MainMenu'));
    this.events.once('shutdown', () => this.input_?.remove());
    this.input_.addEventListener('keydown', (e) => e.key === 'Enter' && this.start());
  }
  pick(g) {
    this.gender = g;
    for (const [k, { card, spr }] of Object.entries(this.cards)) {
      card.setStrokeStyle(k === g ? 8 : 4, k === g ? 0xfcd34d : 0x93c5fd).setFillStyle(k === g ? 0x2563eb : 0x1e3a8a, 0.9);
      spr.setAlpha(k === g ? 1 : 0.55);
    }
  }
  start() {
    const nick = (this.input_.value.trim() || 'Student').slice(0, 16);
    Save.patch({ nick, gender: this.gender });
    this.scene.start('Auditorium', { nick, gender: this.gender });
  }
}
