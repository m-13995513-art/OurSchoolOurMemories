import Phaser from 'phaser';
import { createCharacterAnims } from '../entities/Character.js';
import { GAME_W, GAME_H, COLORS, FONT } from '../config/settings.js';

export class PreloadScene extends Phaser.Scene {
  constructor() { super('Preload'); }
  preload() {
    const bar = this.add.rectangle(GAME_W / 2 - 150, GAME_H / 2, 0, 10, COLORS.gold).setOrigin(0, 0.5);
    this.add.rectangle(GAME_W / 2, GAME_H / 2, 304, 14).setStrokeStyle(2, 0xffffff);
    this.add.text(GAME_W / 2, GAME_H / 2 - 34, 'LOADING…', { fontFamily: FONT, fontSize: '12px', color: '#ffffff' }).setOrigin(0.5);
    this.load.on('progress', (v) => (bar.width = 300 * v));
    this.load.atlas('male', 'assets/characters/characters_male.png', 'assets/characters/characters_male.json');
    this.load.atlas('female', 'assets/characters/characters_female.png', 'assets/characters/characters_female.json');
    this.load.json('anims', 'assets/characters/animations.json');
    this.load.image('floor1', 'assets/maps/auditorium_1f.png');
    this.load.image('floor2', 'assets/maps/auditorium_2f.png');
    this.load.image('overhead', 'assets/maps/auditorium_overhead.png');
  }
  create() {
    createCharacterAnims(this, this.cache.json.get('anims'));
    this.scene.start('MainMenu');
  }
}
