// Local save: nickname, character, mute. Never throws (private mode / blocked storage).
const KEY = 'osom.save.v1';
const DEFAULT = { nick: '', gender: 'male', muted: false };
export const Save = {
  load() { try { return { ...DEFAULT, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch { return { ...DEFAULT }; } },
  patch(p) { const v = { ...this.load(), ...p }; try { localStorage.setItem(KEY, JSON.stringify(v)); } catch {} return v; },
};
