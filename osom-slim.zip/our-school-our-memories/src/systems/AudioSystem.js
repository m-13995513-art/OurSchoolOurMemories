// Procedural audio (WebAudio): no files needed, nothing to license. Unlocks on first user gesture.
export class AudioSystem {
  constructor(muted = false) { this.muted = muted; this.ctx = null; this.stepT = 0; }
  unlock() { if (!this.ctx) { try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch { return; } } this.ctx.resume?.(); }
  setMuted(m) { this.muted = m; }
  tone(freq, dur = 0.12, type = 'square', vol = 0.05, when = 0, slideTo) {
    if (this.muted || !this.ctx) return;
    const t = this.ctx.currentTime + when, o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t); if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.ctx.destination); o.start(t); o.stop(t + dur + 0.02);
  }
  step(running) { const n = performance.now(); if (n - this.stepT < (running ? 170 : 280)) return; this.stepT = n; this.tone(running ? 150 : 120, 0.05, 'triangle', 0.035); }
  click() { this.tone(660, 0.06, 'square', 0.04); }
  door() { this.tone(523, 0.12, 'triangle', 0.06); this.tone(784, 0.18, 'triangle', 0.06, 0.1); }
  sit() { this.tone(220, 0.14, 'sine', 0.06, 0, 140); }
  deny() { this.tone(160, 0.16, 'sawtooth', 0.04); }
  hello() { [523, 659, 784].forEach((f, i) => this.tone(f, 0.1, 'triangle', 0.05, i * 0.08)); }
}
