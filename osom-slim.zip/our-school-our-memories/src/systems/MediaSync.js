// Keeps ONE hidden media element on this client in step with the shared media state.
// Browsers block sound until the user acts, so nothing plays until enable() is called from a click/tap.
export function httpBaseFromWs(ws) { return ws.replace(/^ws/, 'http'); }

export class MediaSync {
  constructor(state, httpBase) {
    this.state = state; this.httpBase = httpBase;
    this.el = document.createElement('video');
    this.el.playsInline = true; this.el.preload = 'auto'; this.el.crossOrigin = 'anonymous';
    this.el.style.cssText = 'width:100%;height:100%;object-fit:contain;background:#000';
    this.enabled = false;
    state.subscribe((k) => { if (k === 'media' || k === 'welcome') this.apply(); });
    this.timer = setInterval(() => this.apply(true), 1500);        // drift correction
  }
  get current() { const m = this.state.media; return m.items[m.index] ?? null; }
  /** call from a user gesture (button click / tap) */
  enable() { this.enabled = true; this.apply(); return this.el.play?.().catch(() => {}); }
  disable() { this.enabled = false; this.el.pause(); }
  apply(soft = false) {
    const m = this.state.media, it = this.current, el = this.el;
    if (!this.enabled || !it) { if (!el.paused) el.pause(); return; }
    const src = this.httpBase + it.url;
    if (el.dataset.src !== src) { el.dataset.src = src; el.src = src; }
    el.volume = m.volume;
    const want = this.state.mediaPosition();
    if (Math.abs(el.currentTime - want) > (soft ? 1.2 : 0.5) && (el.readyState > 0 || !soft)) { try { el.currentTime = want; } catch {} }
    if (m.isPlaying) el.play?.().catch(() => {});
    else if (!el.paused) el.pause();
  }
  destroy() { clearInterval(this.timer); this.el.pause(); this.el.removeAttribute('src'); }
}
