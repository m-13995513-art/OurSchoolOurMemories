// Client mirror of the server-authoritative room state. UI and scenes read from here and subscribe to changes.
import { C2S, S2C } from '../../shared/protocol.js';

export class RoomState {
  constructor(net) {
    this.net = net;
    this.players = new Map();
    this.ppt = { presentationId: null, title: '', totalSlides: 0, currentSlide: 0, isPlaying: false, ended: false, updatedAt: 0 };
    this.media = { items: [], index: 0, isPlaying: false, position: 0, positionAt: 0, volume: 0.8, updatedAt: 0 };
    this.game = { type: null, phase: 'idle' };
    this.files = [];
    this.slides = new Map();          // `${presentationId}:${index}` -> data URL
    this.pending = new Set();
    this.subs = new Set();
    this.lastError = null;
    this.serverClockOffset = 0;       // server now - local now
    const on = (t, f) => net.on(t, f);
    on(S2C.WELCOME, (m) => {
      this.serverClockOffset = m.now - Date.now();
      this.players = new Map(m.players.map((p) => [p.id, p]));
      this.ppt = m.ppt; this.media = m.media; this.game = m.game; this.files = m.files;
      this.pending.clear();
      this.ensureSlides(); this.notify('welcome');
    });
    on(S2C.JOIN, (m) => { this.players.set(m.p.id, m.p); this.notify('players'); });
    on(S2C.LEAVE, (m) => { this.players.delete(m.id); this.notify('players'); });
    on(S2C.SNAP, (m) => { for (const p of m.p) this.players.set(p.id, p); this.notify('snap'); });
    on(S2C.PPT, (m) => { this.ppt = m.state; this.ensureSlides(); this.notify('ppt'); });
    on(S2C.MEDIA, (m) => { this.media = m.state; this.notify('media'); });
    on(S2C.GAME, (m) => { if (m.state) { this.game = m.state; this.myChoice = this.game.phase === 'question' ? this.myChoice : null; } else if (m.ack) this.myChoice = m.choice; this.notify('game'); });
    on(S2C.FILES, (m) => { this.files = m.files; this.notify('files'); });
    on(S2C.SLIDE, (m) => { this.slides.set(`${m.presentationId}:${m.index}`, m.data); this.pending.delete(`${m.presentationId}:${m.index}`); this.notify('slide'); });
    on(S2C.ERROR, (m) => { this.lastError = m.code; this.notify('error'); });
  }
  subscribe(fn) { this.subs.add(fn); return () => this.subs.delete(fn); }
  notify(kind) { this.subs.forEach((f) => f(kind, this)); }
  get serverNow() { return Date.now() + this.serverClockOffset; }

  slide(index = this.ppt.currentSlide) { return this.slides.get(`${this.ppt.presentationId}:${index}`) ?? null; }
  /** fetch the current slide plus the next one, once each */
  ensureSlides() {
    const p = this.ppt;
    if (!p.presentationId) return;
    for (const i of [p.currentSlide, p.currentSlide + 1, p.currentSlide - 1]) {
      if (i < 0 || i >= p.totalSlides) continue;
      const k = `${p.presentationId}:${i}`;
      if (this.slides.has(k) || this.pending.has(k)) continue;
      this.pending.add(k);
      this.net.send({ t: C2S.GET_SLIDE, presentationId: p.presentationId, index: i });
    }
  }
  /** playing position of the shared media, in seconds, as every client should hear it right now */
  mediaPosition() {
    const m = this.media;
    return m.isPlaying ? m.position + (this.serverNow - m.positionAt) / 1000 : m.position;
  }
  cmd(type, payload) { this.net.send({ t: type, ...payload }); }
  ppt_(action, extra = {}) { this.cmd(C2S.PPT, { action, ...extra }); }
  media_(action, extra = {}) { this.cmd(C2S.MEDIA, { action, ...extra }); }
  game_(action, extra = {}) { this.cmd(C2S.GAME, { action, ...extra }); }
}
