// WebSocket client with automatic reconnect. The server keeps a dropped player's place for 60 s,
// so a reconnect (same clientId) resumes position and sees the current slide immediately.
import { C2S, S2C } from '../../shared/protocol.js';

const env = (typeof import.meta !== 'undefined' && import.meta.env) || {};
export const DEFAULT_WS = env.VITE_WS_URL || 'ws://localhost:8787';

export function getClientId() {
  try {
    let id = localStorage.getItem('osom.clientId');
    if (!id) { id = crypto.randomUUID(); localStorage.setItem('osom.clientId', id); }
    return id;
  } catch { return crypto.randomUUID(); }       // private mode: new id per tab
}

export class NetworkClient {
  constructor({ url = DEFAULT_WS, room = 'main', nick = 'Student', gender = 'male', clientId = getClientId() } = {}) {
    Object.assign(this, { url, room, nick, gender, clientId });
    this.handlers = new Map();
    this.status = 'idle';
    this.id = null; this.tries = 0; this.closedByUser = false; this.outbox = [];
    this.latency = 0;
  }
  on(type, fn) { (this.handlers.get(type) ?? this.handlers.set(type, new Set()).get(type)).add(fn); return () => this.handlers.get(type)?.delete(fn); }
  emit(type, data) { this.handlers.get(type)?.forEach((f) => { try { f(data); } catch (e) { console.error(e); } }); }
  setStatus(s) { if (s !== this.status) { this.status = s; this.emit('status', s); } }

  connect() {
    this.closedByUser = false;
    this.setStatus(this.tries ? 'reconnecting' : 'connecting');
    const ws = (this.ws = new WebSocket(`${this.url}/ws?room=${encodeURIComponent(this.room)}`));
    ws.onopen = () => {
      ws.send(JSON.stringify({ t: C2S.HELLO, nick: this.nick, gender: this.gender, clientId: this.clientId }));
    };
    ws.onmessage = (ev) => {
      let m; try { m = JSON.parse(ev.data); } catch { return; }
      if (m.t === S2C.WELCOME) { this.id = m.id; this.tries = 0; this.setStatus('open'); this.outbox.splice(0).forEach((x) => ws.send(x)); }
      if (m.t === S2C.PONG) this.latency = Math.round(performance.now() - m.c);
      this.emit(m.t, m);
    };
    ws.onclose = () => {
      this.id = null;
      if (this.closedByUser) return this.setStatus('closed');
      this.tries++;
      this.setStatus('reconnecting');
      setTimeout(() => !this.closedByUser && this.connect(), Math.min(8000, 500 * 2 ** Math.min(this.tries, 4)));
    };
    ws.onerror = () => {};
    clearInterval(this.pinger);
    this.pinger = setInterval(() => this.send({ t: C2S.PING, c: performance.now() }, true), 5000);
  }
  send(msg, droppable = false) {
    const s = JSON.stringify(msg);
    if (this.ws?.readyState === 1 && this.id) this.ws.send(s);
    else if (!droppable && this.outbox.length < 50) this.outbox.push(s);
  }
  close() { this.closedByUser = true; clearInterval(this.pinger); this.ws?.close(); }
  get open() { return this.status === 'open'; }
}
