// AUDITORIUMC — Presentation Control Center (Computer A). Blue + white console.
// It only SENDS commands; the server owns the presentation state and echoes it to all four screens.
import { h, clear, ICON, fmtBytes } from './dom.js';
import { slidesFromFiles } from './slides.js';
import { drawWheel, wheelAngle } from './wheel.js';

const ERR = {
  not_at_computer: 'Stand in front of this computer to control it.',
  computer_in_use: 'Someone else is using this computer right now.',
  slide_invalid: 'One of the slide images is not valid.', slides_count: 'A presentation can have 1 to 40 slides.',
  slides_too_big: 'This presentation is too large for the room.', no_questions: 'Add at least one complete question first.',
  wheel_entries: 'The wheel needs at least 2 entries.', not_yours: 'You can only delete files you uploaded.', no_such_file: 'That file is no longer available.',
};
const SCREENS = [['main', 'Main Stage Screen'], ['left', 'Left Screen'], ['right', 'Right Screen'], ['rear', 'Rear Screen']];
const GAMES = [
  ['quiz', 'Quiz', '多选题抢答，答得越快分越高', ICON.games],
  ['tf', 'True or False', '判断题，全场一起答', ICON.check],
  ['picture', 'Guess the Picture', '图片由模糊到清晰，越早猜中分越高', ICON.slides],
  ['wheel', 'Spin Wheel', '大转盘，结果由服务器决定', ICON.sync],
  ['challenge', 'Classroom Challenge', '分组计分 + 倒计时', ICON.files],
];
const SAMPLE_QUIZ = [
  { q: 'What is 7 × 8?', options: ['54', '56', '58', '64'], correct: 1 },
  { q: 'Which planet is closest to the Sun?', options: ['Venus', 'Earth', 'Mercury', 'Mars'], correct: 2 },
  { q: 'How many sides does a hexagon have?', options: ['5', '6', '7', '8'], correct: 1 },
];

export class AuditoriumC {
  constructor(state, { onClose } = {}) {
    this.state = state; this.onClose = onClose;
    this.page = 'home'; this.gameType = null; this.busy = ''; this.error = ''; this.toastTimer = 0;
    this.draft = {
      quiz: structuredClone(SAMPLE_QUIZ), tf: [{ q: 'The Sun is a star.', correct: 0 }],
      picture: { q: 'What is in the picture?', options: ['', '', '', ''], correct: 0, image: null, imageName: '' },
      wheel: 'Amy\nBen\nCara\nDan\nEve', challenge: { teams: ['Team A', 'Team B', 'Team C', 'Team D'], seconds: 60 }, seconds: 20,
    };
    this.tickers = [];
    this.build();
    this.unsub = state.subscribe((kind) => this.onState(kind));
    this.timer = setInterval(() => this.tickers.forEach((f) => f()), 200);
    this.raf = 0;
  }

  // ------------------------------------------------------------ shell
  build() {
    this.main = h('div', { class: 'ac-main', id: 'ac-main' });
    this.barFill = h('i');
    this.footText = h('span');
    this.status = h('span', { class: 'ac-chip' }, h('b'), h('em', { style: { fontStyle: 'normal' } }, 'Connected'));
    this.rail = h('nav', { class: 'ac-rail', 'aria-label': 'AUDITORIUMC sections' },
      ...[['home', ICON.home, 'Home'], ['ppt', ICON.slides, 'PPT Player'], ['games', ICON.games, 'PPT Games'], ['sync', ICON.sync, 'Screen Sync'], ['files', ICON.files, 'My Files']]
        .map(([p, ic, label]) => h('button', { html: ic, 'data-page': p, title: label, 'aria-label': label, onClick: () => this.go(p) })));
    this.root = h('div', { class: 'osom-overlay', role: 'dialog', 'aria-label': 'AUDITORIUMC Presentation Control Center', id: 'auditoriumc' },
      h('div', { class: 'ac' },
        h('header', { class: 'ac-head' },
          h('div', { class: 'ac-logo' }, h('i', { html: ICON.slides }), h('span', {}, 'AUDITORIUMC')),
          h('div', { class: 'ac-title' }, 'PRESENTATION CONTROL CENTER'),
          this.status,
          h('button', { class: 'ac-x', html: ICON.close, 'aria-label': 'Close', id: 'ac-close', onClick: () => this.close() })),
        this.rail, this.main,
        h('footer', { class: 'ac-foot' }, h('div', { class: 'ac-bar' }, this.barFill), this.footText)));
    this.keyHandler = (e) => {
      if (this.root.hidden || /INPUT|TEXTAREA/.test(document.activeElement?.tagName || '')) return;
      if (e.key === 'Escape') { e.stopPropagation(); this.close(); }
      if (this.page === 'ppt' && this.state.ppt.presentationId) {
        if (e.key === 'ArrowRight' || e.key === 'PageDown') this.state.ppt_('next');
        if (e.key === 'ArrowLeft' || e.key === 'PageUp') this.state.ppt_('prev');
        if (e.key === ' ') { e.preventDefault(); this.togglePlay(); }
      }
    };
    window.addEventListener('keydown', this.keyHandler, true);
    this.render();
  }

  open(page = 'home') { document.body.append(this.root); this.root.hidden = false; this.go(page); this.root.querySelector('.ac-rail button[aria-current="page"]')?.focus(); }
  close() { this.root.hidden = true; this.root.remove(); this.state.ppt_('release'); this.onClose?.(); }
  destroy() { clearInterval(this.timer); this.unsub?.(); window.removeEventListener('keydown', this.keyHandler, true); this.root.remove(); }
  go(p) { this.page = p; this.error = ''; this.render(); }
  toast(msg) { this.root.querySelector('.ac-toast')?.remove(); const t = h('div', { class: 'ac-toast', role: 'status' }, msg); this.root.querySelector('.ac').append(t); clearTimeout(this.toastTimer); this.toastTimer = setTimeout(() => t.remove(), 2600); }

  onState(kind) {
    if (this.root.hidden) return;
    if (kind === 'error') return this.toast(ERR[this.state.lastError] ?? 'Something went wrong (' + this.state.lastError + ')');
    if (kind === 'snap' || kind === 'players') { if (this.page === 'games' || this.page === 'sync') this.updateMeta(); return; }
    if (kind === 'slide') { this.updateStage(); if (this.page === 'sync') this.render(); return; }
    this.render();
  }

  render() {
    this.tickers = [];
    cancelAnimationFrame(this.raf);
    this.rail.querySelectorAll('button').forEach((b) => (b.dataset.page === this.page ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current')));
    clear(this.main).append({ home: () => this.pageHome(), ppt: () => this.pagePPT(), games: () => this.pageGames(), sync: () => this.pageSync(), files: () => this.pageFiles() }[this.page]());
    if (this.page === "ppt") this.updateStage();
    this.updateMeta();
  }

  updateMeta() {
    const s = this.state, p = s.ppt, open = s.net.open;
    this.status.classList.toggle('bad', !open);
    this.status.querySelector('em').textContent = open ? `Connected · ${s.players.size} in room` : 'Reconnecting…';
    const pct = p.presentationId ? ((p.currentSlide + 1) / p.totalSlides) * 100 : 0;
    this.barFill.style.width = pct + '%';
    this.footText.textContent = open ? '4 Displays Connected · Synchronized' : 'Offline — screens will resync automatically';
  }

  // ------------------------------------------------------------ HOME
  pageHome() {
    const tile = (page, title, sub, icon, hot) => h('button', { class: 'ac-tile' + (hot ? ' hot' : ''), 'data-tile': page, onClick: () => this.go(page) },
      h('div', { class: 'ic', html: icon }), h('div', {}, h('strong', {}, title), h('span', {}, sub)));
    return h('div', { class: 'ac-tiles' },
      tile('ppt', 'PPT Player', '播放幻灯片', ICON.slides, true), tile('games', 'PPT Games', '互动小游戏', ICON.games),
      tile('sync', 'Screen Sync', '四屏同步', ICON.sync), tile('files', 'My Files', '选择文件', ICON.files, true));
  }

  // ------------------------------------------------------------ PPT PLAYER
  pagePPT() {
    const s = this.state, p = s.ppt;
    if (!p.presentationId) return this.pageUpload();
    this.stage = h('div', { class: 'ac-stage', id: 'ac-stage' });
    const badge = h('div', { class: 'badge' }, h('b'), h('span'));
    this.stage.append(badge);
    const count = h('div', { class: 'count', id: 'ac-count' });
    const mk = (ic, label, fn, cls = '') => h('button', { class: 'ac-btn round ' + cls, html: ICON[ic], title: label, 'aria-label': label, onClick: fn });
    const playBtn = mk('play', 'Play / Pause', () => this.togglePlay(), 'pri'); playBtn.id = 'ac-play';
    const chips = h('div', { class: 'ac-chips' }, ...Array.from({ length: p.totalSlides }, (_, i) => h('button', { 'data-slide': i, onClick: () => s.ppt_('goto', { index: i }) }, String(i + 1))));
    const update = () => {
      const q = s.ppt; if (!q.presentationId) return;
      count.textContent = `${q.currentSlide + 1} / ${q.totalSlides}`;
      badge.className = 'badge' + (q.ended ? ' ended' : q.isPlaying ? '' : ' paused');
      badge.lastChild.textContent = q.ended ? 'ENDED' : q.isPlaying ? 'LIVE on 4 screens' : 'PAUSED on 4 screens';
      playBtn.innerHTML = q.isPlaying ? ICON.pause : ICON.play;
      chips.querySelectorAll('button').forEach((b) => b.classList.toggle('on', Number(b.dataset.slide) === q.currentSlide));
      this.updateStage();
    };
    update();
    return h('div', {},
      h('h2', {}, 'PPT Player', h('small', {}, p.title)),
      h('div', { class: 'ac-ppt' },
        h('div', {}, this.stage,
          h('div', { class: 'ac-ctl' }, mk('prev', 'Previous slide', () => s.ppt_('prev')), playBtn, mk('next', 'Next slide', () => s.ppt_('next')), count,
            mk('stop', 'End presentation', () => s.ppt_('end')), mk('full', 'Full screen', () => this.stage.requestFullscreen?.())),
          h('div', { class: 'ac-row', style: { marginTop: '14px', justifyContent: 'center' } },
            h('button', { class: 'ac-btn', onClick: () => s.ppt_('restart') }, 'Restart'),
            h('button', { class: 'ac-btn', onClick: () => { s.ppt_('unload'); } }, ICON.upload && h('span', { html: ICON.upload }), 'Upload another'))),
        h('div', {}, h('div', { class: 'ac-note', style: { marginBottom: '8px' } }, 'Jump to slide'), chips)));
  }
  updateStage() {
    const st = this.stage; if (!st || !st.isConnected) return;
    const url = this.state.slide();
    st.style.backgroundImage = url ? `url("${url}")` : 'none';
    st.querySelector('.over')?.remove();
    if (!url) st.append(h('div', { class: 'over' }, 'Loading slide…'));
    else if (this.state.ppt.ended) st.append(h('div', { class: 'over' }, 'END OF PRESENTATION'));
  }
  togglePlay() { const p = this.state.ppt; this.state.ppt_(p.isPlaying ? 'pause' : (p.ended ? 'restart' : 'play')); }

  pageUpload() {
    const input = h('input', { type: 'file', multiple: true, accept: '.pdf,application/pdf,image/png,image/jpeg,image/webp', hidden: true, id: 'ac-file', onChange: () => this.upload(input.files) });
    const drop = h('div', { class: 'ac-drop', id: 'ac-drop' },
      h('div', { class: 'ic', html: ICON.upload }),
      h('strong', { style: { fontSize: '20px' } }, 'Upload a presentation'),
      h('div', { class: 'ac-note' }, 'Supported: PDF, or PNG / JPG / WEBP images (sorted by name).', h('br'), 'PowerPoint (.pptx): in PowerPoint use File → Save As → PDF, then upload the PDF.'),
      h('button', { class: 'ac-btn pri', onClick: () => input.click() }, this.busy || 'Choose file'),
      input);
    ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', (e) => this.upload(e.dataTransfer.files));
    return h('div', {}, h('h2', {}, 'PPT Player', h('small', {}, 'nothing is playing')), drop, this.error && h('div', { class: 'ac-err', style: { marginTop: '14px' }, role: 'alert' }, this.error));
  }
  async upload(files) {
    this.error = '';
    try {
      this.busy = 'Preparing slides…'; this.render();
      const { slides, title, notes } = await slidesFromFiles(files, (i, n) => { const b = this.main.querySelector('.ac-drop .ac-btn'); if (b) b.textContent = `Preparing slides… ${i}/${n}`; });
      this.busy = '';
      this.state.ppt_('load', { title, slides });
      if (notes.length) this.toast(notes.join(' '));
    } catch (e) { this.busy = ''; this.error = e.message; this.render(); }
  }

  // ------------------------------------------------------------ GAMES
  pageGames() {
    const g = this.state.game;
    if (g.type) return this.gameLive(g);
    if (this.gameType) return this.gameConfig(this.gameType);
    return h('div', {}, h('h2', {}, 'PPT Games', h('small', {}, 'everyone in the auditorium can join from their phone or keyboard')),
      h('div', { class: 'ac-cards' }, ...GAMES.map(([id, title, sub, icon]) => h('button', { class: 'ac-card game', 'data-game': id, onClick: () => { this.gameType = id; this.render(); } },
        h('div', { class: 'ic', html: icon }), h('h3', {}, title), h('p', {}, sub)))));
  }

  gameConfig(type) {
    const d = this.draft, title = GAMES.find((x) => x[0] === type)[1];
    const back = h('button', { class: 'ac-btn', onClick: () => { this.gameType = null; this.render(); } }, '← All games');
    const start = (payload) => this.state.game_('start', { type, ...payload });
    const text = (label, get, set, extra = {}) => h('label', {}, label, h('input', { type: 'text', value: get(), maxlength: extra.max || 140, onInput: (e) => set(e.target.value), ...extra }));
    let body;
    if (type === 'quiz' || type === 'tf') {
      const list = d[type];
      const blocks = list.map((q, qi) => type === 'tf'
        ? h('div', { class: 'ac-q' }, text(`Statement ${qi + 1}`, () => q.q, (v) => (q.q = v)),
          h('div', { class: 'ac-row' }, ...['True', 'False'].map((t, i) => h('label', { class: 'opt', style: { flexDirection: 'row' } }, h('input', { type: 'radio', name: 'tf' + qi, checked: q.correct === i, onChange: () => (q.correct = i) }), t))))
        : h('div', { class: 'ac-q' }, text(`Question ${qi + 1}`, () => q.q, (v) => (q.q = v)),
          h('div', { class: 'opts' }, ...q.options.map((o, oi) => h('div', { class: 'opt' }, h('input', { type: 'radio', name: 'q' + qi, checked: q.correct === oi, title: 'Correct answer', onChange: () => (q.correct = oi) }),
            h('input', { type: 'text', value: o, placeholder: 'Option ' + 'ABCD'[oi], maxlength: 60, style: { flex: 1, border: '1.5px solid var(--ac-line)', borderRadius: '11px', padding: '8px 10px' }, onInput: (e) => (q.options[oi] = e.target.value) }))))));
      body = h('div', { class: 'ac-form' }, ...blocks,
        h('div', { class: 'ac-row' },
          h('button', { class: 'ac-btn', onClick: () => { list.push(type === 'tf' ? { q: '', correct: 0 } : { q: '', options: ['', '', '', ''], correct: 0 }); this.render(); } }, '+ Add'),
          list.length > 1 && h('button', { class: 'ac-btn bad', onClick: () => { list.pop(); this.render(); } }, 'Remove last')),
        h('label', {}, 'Seconds per question', h('input', { type: 'number', min: 5, max: 120, value: d.seconds, onInput: (e) => (d.seconds = Number(e.target.value)) })),
        h('button', { class: 'ac-btn pri', id: 'ac-start', onClick: () => start({ questions: list.map((q) => (type === 'tf' ? q : { ...q, options: q.options.filter((o) => o.trim()) })).filter((q) => q.q.trim()), seconds: d.seconds }) }, 'Start game'));
    } else if (type === 'picture') {
      const p = d.picture;
      const fileIn = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', onChange: async () => { const f = fileIn.files[0]; if (f) { p.image = await shrink(f); p.imageName = f.name; this.render(); } } });
      body = h('div', { class: 'ac-form' }, h('label', {}, 'Picture (starts blurred, gets clearer)', fileIn), p.image && h('img', { src: p.image, style: { maxWidth: '260px', borderRadius: '12px' }, alt: '' }),
        text('Question', () => p.q, (v) => (p.q = v)),
        h('div', { class: 'ac-q' }, h('div', { class: 'opts' }, ...p.options.map((o, oi) => h('div', { class: 'opt' }, h('input', { type: 'radio', name: 'pic', checked: p.correct === oi, onChange: () => (p.correct = oi) }),
          h('input', { type: 'text', value: o, placeholder: 'Option ' + 'ABCD'[oi], maxlength: 60, style: { flex: 1, border: '1.5px solid var(--ac-line)', borderRadius: '11px', padding: '8px 10px' }, onInput: (e) => (p.options[oi] = e.target.value) }))))),
        h('label', {}, 'Seconds', h('input', { type: 'number', min: 5, max: 120, value: d.seconds, onInput: (e) => (d.seconds = Number(e.target.value)) })),
        h('button', { class: 'ac-btn pri', id: 'ac-start', disabled: !p.image, onClick: () => start({ questions: [{ q: p.q, options: p.options.filter((o) => o.trim()), correct: p.correct, image: p.image }], seconds: d.seconds }) }, 'Start game'));
    } else if (type === 'wheel') {
      body = h('div', { class: 'ac-form' }, h('label', {}, 'Entries (one per line, up to 16)', h('textarea', { rows: 7, onInput: (e) => (d.wheel = e.target.value) }, d.wheel)),
        h('button', { class: 'ac-btn pri', id: 'ac-start', onClick: () => start({ entries: d.wheel.split('\n') }) }, 'Start game'));
    } else {
      const c = d.challenge;
      body = h('div', { class: 'ac-form' }, ...c.teams.map((t, i) => text('Team ' + (i + 1), () => t, (v) => (c.teams[i] = v), { max: 16 })),
        h('label', {}, 'Timer seconds', h('input', { type: 'number', min: 10, max: 600, value: c.seconds, onInput: (e) => (c.seconds = Number(e.target.value)) })),
        h('button', { class: 'ac-btn pri', id: 'ac-start', onClick: () => start({ teams: c.teams, seconds: c.seconds }) }, 'Start game'));
    }
    return h('div', {}, h('div', { class: 'ac-row', style: { marginBottom: '10px' } }, back), h('h2', {}, title), body);
  }

  gameLive(g) {
    const s = this.state, wrap = h('div', { class: 'ac-live' });
    const title = GAMES.find((x) => x[0] === g.type)?.[1] ?? 'Game';
    const stop = h('button', { class: 'ac-btn bad', id: 'ac-stop', onClick: () => { s.game_('stop'); this.gameType = null; } }, 'Stop game');
    wrap.append(h('h2', {}, title, h('small', {}, '')), );
    const meta = wrap.querySelector('small');
    if (['quiz', 'tf', 'picture'].includes(g.type)) {
      const q = g.question;
      const countdown = h('span', { class: 'ac-pill' });
      wrap.append(h('div', { class: 'ac-row' }, h('strong', {}, `Question ${g.qIndex + 1} / ${g.total}`), countdown, h('span', { class: 'ac-pill', id: 'ac-answered' }, `${g.answered} / ${s.players.size} answered`)));
      if (q?.image) wrap.append(h('img', { src: q.image, alt: '', style: { maxHeight: '170px', borderRadius: '12px', alignSelf: 'start' } }));
      wrap.append(h('div', { style: { fontSize: '22px', fontWeight: 800 } }, q?.q ?? ''));
      const total = Math.max(1, g.counts?.reduce((a, b) => a + b, 0) || 1);
      (q?.options ?? []).forEach((o, i) => wrap.append(h('div', { class: 'ac-opt' + (q.correct === i ? ' right' : '') }, g.counts && h('i', { style: { width: (g.counts[i] / total) * 100 + '%' } }), h('span', {}, 'ABCD'[i] + '  ' + o), g.counts && h('em', {}, g.counts[i] + ' votes'))));
      wrap.append(h('div', { class: 'ac-row' },
        h('button', { class: 'ac-btn pri', id: 'ac-reveal', disabled: g.phase !== 'question', onClick: () => s.game_('reveal') }, 'Reveal answer'),
        h('button', { class: 'ac-btn', id: 'ac-next', disabled: g.phase !== 'reveal', onClick: () => s.game_('next') }, g.qIndex + 1 >= g.total ? 'Finish' : 'Next question'), stop));
      if (g.scores?.length) wrap.append(h('div', { class: 'ac-board' }, h('strong', {}, 'Leaderboard'), ...g.scores.map((r, i) => h('div', {}, `${i + 1}. ${r.nick}`, h('b', {}, r.score)))));
      this.tickers.push(() => { const left = g.phase === 'question' ? Math.max(0, Math.ceil((g.deadline - s.serverNow) / 1000)) : 0; countdown.textContent = g.phase === 'question' ? `${left}s left` : g.phase === 'reveal' ? 'Answer shown' : 'Finished'; });
    } else if (g.type === 'wheel') {
      const cv = h('canvas', { width: 420, height: 420, style: { width: '300px', height: '300px', justifySelf: 'center' }, id: 'ac-wheel' });
      const res = h('div', { style: { fontSize: '26px', fontWeight: 900, textAlign: 'center', minHeight: '34px' } });
      wrap.append(cv, res, h('div', { class: 'ac-row', style: { justifyContent: 'center' } }, h('button', { class: 'ac-btn pri', id: 'ac-spin', disabled: g.phase === 'spinning', onClick: () => s.game_('spin') }, 'SPIN'), stop));
      const loop = () => { drawWheel(cv, g.entries, wheelAngle(g, s.serverNow), g.phase === 'result' ? g.resultIndex : null); res.textContent = g.phase === 'result' ? '🎉 ' + g.entries[g.resultIndex] : ''; if (cv.isConnected) this.raf = requestAnimationFrame(loop); };
      loop();
    } else if (g.type === 'challenge') {
      const clock = h('div', { class: 'ac-clock' });
      wrap.append(clock, h('div', { class: 'ac-row', style: { justifyContent: 'center' } }, h('button', { class: 'ac-btn pri', id: 'ac-timer', onClick: () => s.game_('timer', { run: !g.running }) }, g.running ? 'Stop timer' : 'Start timer'), stop),
        h('div', { class: 'ac-teams' }, ...g.teams.map((t, i) => h('div', { class: 'ac-team', 'data-team': i }, h('strong', {}, t.name), h('div', { class: 'score' }, t.score),
          h('div', { class: 'ac-row', style: { justifyContent: 'center' } }, ...[[-1, '−1'], [1, '+1'], [5, '+5'], [10, '+10']].map(([dl, lb]) => h('button', { class: 'ac-btn', onClick: () => s.game_('points', { team: i, delta: dl }) }, lb)))))));
      this.tickers.push(() => { clock.textContent = g.running ? fmtClock((g.endsAt - s.serverNow) / 1000) : '--:--'; });
    }
    return wrap;
  }

  // ------------------------------------------------------------ SCREEN SYNC
  pageSync() {
    const s = this.state, p = s.ppt, url = s.slide();
    const card = ([id, label]) => h('div', { class: 'ac-mon', 'data-screen': id },
      h('strong', {}, label),
      h('div', { class: 'scr', style: { backgroundImage: url ? `url("${url}")` : 'none' } }, !url && 'NO SIGNAL'),
      h('div', { class: 'meta' }, h('span', {}, p.presentationId ? `Slide ${p.currentSlide + 1} / ${p.totalSlides}` : '—'),
        h('span', { class: 'ac-pill' + (s.net.open ? '' : ' bad') }, s.net.open ? 'Synced' : 'Offline')),
      h('div', { class: 'meta' }, h('span', {}, p.ended ? 'Ended' : p.isPlaying ? 'Playing' : p.presentationId ? 'Paused' : 'Idle'), h('span', {}, p.updatedAt ? ago(s.serverNow - p.updatedAt) : '')));
    const raw = { presentationId: p.presentationId, currentSlide: p.currentSlide, isPlaying: p.isPlaying, totalSlides: p.totalSlides, updatedAt: p.updatedAt };
    return h('div', {}, h('h2', {}, 'Screen Sync', h('small', {}, 'all four screens read one shared state')),
      h('div', { class: 'ac-sync' }, ...SCREENS.map(card)),
      h('div', { class: 'ac-note', style: { margin: '14px 0 6px' } }, 'Shared presentation state (server)'),
      h('div', { class: 'ac-mono', id: 'ac-raw' }, JSON.stringify(raw, null, 1)));
  }

  // ------------------------------------------------------------ MY FILES
  pageFiles() {
    const s = this.state;
    const rows = s.files.map((f) => h('div', { class: 'ac-file', 'data-file': f.id },
      h('div', { class: 'ic', html: f.kind === 'ppt' ? ICON.slides : ICON.music }),
      h('div', { class: 'nm' }, h('div', {}, f.name), h('small', {}, `${f.kind === 'ppt' ? f.slides + ' slides' : 'media'} · ${fmtBytes(f.bytes)} · ${f.mine ? 'uploaded by you' : 'uploaded by someone else'}`)),
      f.kind === 'ppt' && h('button', { class: 'ac-btn', onClick: () => { s.ppt_('open', { id: f.id }); this.go('ppt'); } }, 'Open'),
      h('button', { class: 'ac-btn bad', disabled: !f.mine, title: f.mine ? 'Delete' : 'You can only delete your own files', html: ICON.trash, 'aria-label': 'Delete ' + f.name, onClick: () => s.cmd('fileDelete', { id: f.id }) })));
    return h('div', {}, h('h2', {}, 'My Files', h('small', {}, 'files shared in this room')), rows.length ? h('div', { class: 'ac-live' }, ...rows) : h('div', { class: 'ac-drop' }, h('div', { class: 'ic', html: ICON.files }), h('div', { class: 'ac-note' }, 'No files yet. Upload a presentation in PPT Player.')));
  }
}

const fmtClock = (s) => { s = Math.max(0, Math.ceil(s)); return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };
const ago = (ms) => (ms < 1500 ? 'just now' : ms < 60000 ? Math.round(ms / 1000) + 's ago' : Math.round(ms / 60000) + 'm ago');

async function shrink(file) {
  const url = URL.createObjectURL(file);
  const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
  const k = Math.min(1, 800 / img.naturalWidth, 450 / img.naturalHeight);
  const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
  c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
  return c.toDataURL('image/jpeg', 0.8);
}
