// Minimal in-game HUD (DOM overlay): where am I, who is here, what can I interact with.
import { h, clear } from './dom.js';

const I = {
  map: '<svg viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z"/><path d="M9 4v14M15 6v14"/></svg>',
  gear: '<svg viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/></svg>',
  users: '<svg viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-4 3-6 6.5-6s5.9 2 6.5 6M16 5a3.2 3.2 0 0 1 0 6.2M18 14c2 .6 3.2 2.4 3.5 5"/></svg>',
  sound: '<svg viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 9v6h4l5 4V5L8 9z" fill="currentColor"/><path d="M16 9a4 4 0 0 1 0 6"/></svg>',
};

export class HUD {
  constructor({ nick = 'Student', onMap, onSettings, onAudio } = {}) {
    this.loc = h('span', { id: 'hud-loc' }, '—'); this.count = h('span', { id: 'hud-count' }, '1');
    this.conn = h('div', { class: 'hud-pill', id: 'hud-conn' }, h('b'), h('span', {}, 'Offline'));
    this.prompt = h('div', { class: 'hud-prompt', id: 'hud-prompt', hidden: true });
    this.toastEl = h('div', { class: 'hud-toast', id: 'hud-toast', hidden: true, role: 'status' });
    this.list = h('div', { class: 'hud-list', id: 'hud-list', hidden: true });
    this.audio = h('button', { class: 'hud-btn', html: I.sound, title: 'Join auditorium audio', 'aria-label': 'Join audio', id: 'hud-audio', hidden: true, onClick: () => onAudio?.() });
    this.root = h('div', { class: 'hud', id: 'hud' },
      h('div', { class: 'hud-top' },
        h('div', { class: 'hud-pill' }, h('span', {}, '📍'), this.loc), h('div', { class: 'hud-pill', id: 'hud-nick' }, nick), this.conn, h('span', { class: 'hud-sp' }),
        this.audio,
        h('button', { class: 'hud-btn', html: I.users, title: 'Players', 'aria-label': 'Players', id: 'hud-players', onClick: () => (this.list.hidden = !this.list.hidden) }),
        h('button', { class: 'hud-btn', html: I.map, title: 'Map', 'aria-label': 'Map', id: 'hud-map', onClick: () => onMap?.() }),
        h('button', { class: 'hud-btn', html: I.gear, title: 'Settings', 'aria-label': 'Settings', id: 'hud-settings', onClick: () => onSettings?.() })),
      this.list, this.prompt, this.toastEl);
    document.body.append(this.root);
  }
  setLocation(t) { this.loc.textContent = t; }
  setConnection(status, count) {
    const ok = status === 'open';
    this.conn.className = 'hud-pill' + (ok ? '' : status === 'reconnecting' ? ' warn' : ' bad');
    this.conn.lastChild.textContent = ok ? `${count} online` : status === 'reconnecting' ? 'Reconnecting…' : status === 'connecting' ? 'Connecting…' : 'Offline';
  }
  setPrompt(text, key = 'E') { if (!text) { this.prompt.hidden = true; return; } this.prompt.hidden = false; clear(this.prompt).append(h('kbd', {}, key), text); }
  toast(msg, ms = 2400) { this.toastEl.textContent = msg; this.toastEl.hidden = false; clearTimeout(this._t); this._t = setTimeout(() => (this.toastEl.hidden = true), ms); }
  setPlayers(players, meId) { clear(this.list).append(...players.map((p) => h('div', { class: p.id === meId ? 'me' : '' }, h('i'), p.nick + (p.id === meId ? ' (you)' : '')))); this.count.textContent = String(players.length); }
  showAudioButton(v) { this.audio.hidden = !v; }
  destroy() { this.root.remove(); }
}
