// Turns uploaded files into slide images that every client can display.
// Supported: PDF (via pdf.js), PNG / JPG / WEBP image sequences.
// NOT supported in the browser: .pptx / .ppt — export to PDF first (the UI says so).
import { LIMITS } from '../../shared/protocol.js';

export const SUPPORTED = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp'];
export const SLIDE_W = 1280, SLIDE_H = 720;

export function classify(file) {
  const n = file.name.toLowerCase();
  if (/\.(pptx?|key|odp)$/.test(n)) return 'office';
  if (file.type === 'application/pdf' || n.endsWith('.pdf')) return 'pdf';
  if (/^image\/(png|jpeg|webp)$/.test(file.type) || /\.(png|jpe?g|webp)$/.test(n)) return 'image';
  return 'unsupported';
}

function toJpegDataUrl(source, sw, sh) {
  const c = document.createElement('canvas');
  c.width = SLIDE_W; c.height = SLIDE_H;
  const g = c.getContext('2d');
  g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
  const k = Math.min(SLIDE_W / sw, SLIDE_H / sh);
  const w = sw * k, hh = sh * k;
  g.imageSmoothingQuality = 'high';
  g.drawImage(source, (SLIDE_W - w) / 2, (SLIDE_H - hh) / 2, w, hh);
  for (let q = 0.85; q >= 0.4; q -= 0.1) {                      // shrink until it fits the per-slide limit
    const url = c.toDataURL('image/jpeg', q);
    if (url.length <= LIMITS.slideBytes * 1.3) return url;
  }
  return c.toDataURL('image/jpeg', 0.35);
}

const loadImage = (file) => new Promise((res, rej) => {
  const url = URL.createObjectURL(file); const img = new Image();
  img.onload = () => { res(img); setTimeout(() => URL.revokeObjectURL(url), 1000); };
  img.onerror = () => rej(new Error('Cannot read image ' + file.name));
  img.src = url;
});

export async function pdfToSlides(file, onProgress) {
  const pdfjs = await import('pdfjs-dist');
  if (pdfjs.GlobalWorkerOptions && !pdfjs.GlobalWorkerOptions.workerSrc) {
    // Vite resolves the `?url` import to a hashed asset; the test harness (no bundler) sets window.__PDFJS_WORKER__.
    pdfjs.GlobalWorkerOptions.workerSrc = (typeof window !== 'undefined' && window.__PDFJS_WORKER__) || (await import('pdfjs-dist/build/pdf.worker.min.mjs?url')).default;
  }
  const doc = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
  const n = Math.min(doc.numPages, LIMITS.slides);
  const out = [];
  for (let i = 1; i <= n; i++) {
    const page = await doc.getPage(i);
    const vp0 = page.getViewport({ scale: 1 });
    const scale = Math.min(2, SLIDE_W / vp0.width * 1.5);
    const vp = page.getViewport({ scale });
    const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
    await page.render({ canvasContext: c.getContext('2d'), viewport: vp, background: '#ffffff' }).promise;
    out.push(toJpegDataUrl(c, c.width, c.height));
    onProgress?.(i, n);
  }
  return { slides: out, truncated: doc.numPages > n };
}

/** @returns {{slides:string[], title:string, notes:string[]}} */
export async function slidesFromFiles(files, onProgress) {
  const list = [...files];
  const notes = [];
  if (!list.length) throw new Error('No file selected');
  const kinds = list.map(classify);
  if (kinds.includes('office')) throw new Error('PowerPoint files cannot be played directly in the browser. In PowerPoint choose File → Save As → PDF, then upload the PDF.');
  if (kinds.includes('unsupported')) throw new Error('Unsupported file. Use PDF, PNG, JPG or WEBP.');
  let slides = [];
  const title = list[0].name.replace(/\.[^.]+$/, '');
  if (kinds[0] === 'pdf') {
    const r = await pdfToSlides(list[0], onProgress);
    slides = r.slides;
    if (r.truncated) notes.push(`Only the first ${LIMITS.slides} pages are used.`);
  } else {
    const imgs = list.filter((_, i) => kinds[i] === 'image').sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true })).slice(0, LIMITS.slides);
    for (let i = 0; i < imgs.length; i++) {
      const img = await loadImage(imgs[i]);
      slides.push(toJpegDataUrl(img, img.naturalWidth, img.naturalHeight));
      onProgress?.(i + 1, imgs.length);
    }
  }
  const total = slides.reduce((a, s) => a + s.length, 0);
  if (total > LIMITS.totalSlideBytes * 1.3) throw new Error('This file is too large for the room (limit about 14 MB of slides). Try fewer pages.');
  return { slides, title, notes };
}
