// Spin-wheel rendering shared by the control console and the audience panel.
// The server decides the winner; every client animates the same spin from (startedAt, duration, finalTurns, resultIndex).
const COLORS = ['#ff8fb1', '#ffd36e', '#8fd8ff', '#b9a4ff', '#8ff0c0', '#ffb68f', '#a8e063', '#ff9ff3'];
const TAU = Math.PI * 2;

export function wheelAngle(g, now) {
  if (!g || !g.entries || (g.phase !== 'spinning' && g.phase !== 'result')) return 0;
  const seg = TAU / g.entries.length;
  const target = (((-Math.PI / 2 - (g.resultIndex * seg + seg / 2)) % TAU) + TAU) % TAU;   // result centre under the top pointer
  const total = g.finalTurns * TAU + target;
  if (g.phase === 'result') return total;
  const t = Math.min(1, Math.max(0, (now - g.startedAt) / g.duration));
  return (1 - Math.pow(1 - t, 3)) * total;
}

export function drawWheel(canvas, entries, angle, highlight = null) {
  const s = canvas.width, c = canvas.getContext('2d'), r = s / 2 - 14, n = entries.length, seg = TAU / n;
  c.clearRect(0, 0, s, s);
  c.save(); c.translate(s / 2, s / 2);
  c.shadowColor = 'rgba(0,0,0,.25)'; c.shadowBlur = 14; c.fillStyle = '#fff'; c.beginPath(); c.arc(0, 0, r + 6, 0, TAU); c.fill(); c.shadowBlur = 0;
  c.rotate(angle);
  for (let i = 0; i < n; i++) {
    c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, r, i * seg, (i + 1) * seg); c.closePath();
    c.fillStyle = COLORS[i % COLORS.length]; c.fill();
    c.lineWidth = 2; c.strokeStyle = '#fff'; c.stroke();
    if (highlight === i) { c.fillStyle = 'rgba(255,255,255,.45)'; c.fill(); }
    c.save(); c.rotate(i * seg + seg / 2); c.fillStyle = '#2a1633'; c.font = `800 ${Math.max(12, Math.min(22, r / (n > 8 ? 9 : 7)))}px sans-serif`;
    c.textAlign = 'right'; c.textBaseline = 'middle';
    let t = entries[i]; if (t.length > 11) t = t.slice(0, 10) + '…';
    c.fillText(t, r - 14, 0); c.restore();
  }
  c.restore();
  c.save(); c.translate(s / 2, s / 2);
  c.fillStyle = '#fff'; c.beginPath(); c.arc(0, 0, 20, 0, TAU); c.fill(); c.fillStyle = '#2a7bff'; c.beginPath(); c.arc(0, 0, 9, 0, TAU); c.fill();
  c.restore();
  c.fillStyle = '#e5484d'; c.strokeStyle = '#fff'; c.lineWidth = 3; c.beginPath(); c.moveTo(s / 2 - 13, 2); c.lineTo(s / 2 + 13, 2); c.lineTo(s / 2, 32); c.closePath(); c.stroke(); c.fill();
}
