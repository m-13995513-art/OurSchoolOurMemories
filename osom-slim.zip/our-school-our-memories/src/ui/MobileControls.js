// Virtual joystick + buttons. Pointer Events with per-pointer tracking => real multi-touch
// (move with one thumb while pressing Interact / Run with the other).
import { h } from './dom.js';

const DEAD = 0.16;

export class MobileControls {
  constructor({ onInteract, onMenu, forceShow = false } = {}) {
    this.vector = { x: 0, y: 0 }; this.run = false; this.onInteract = onInteract;
    this.stickPtr = null; this.knob = h('div', { class: 'tc-knob' });
    this.stick = h('div', { class: 'tc-stick', id: 'tc-stick' }, this.knob);
    this.act = h('button', { class: 'tc-btn tc-act', id: 'tc-act', 'aria-label': 'Interact' }, 'A');
    this.runBtn = h('button', { class: 'tc-btn tc-run', id: 'tc-run', 'aria-label': 'Run' }, 'RUN');
    this.root = h('div', { class: 'tc', id: 'tc' }, this.stick, this.runBtn, this.act);
    if (forceShow) this.root.style.display = 'block';
    document.body.append(this.root);
    // keep the browser from scrolling / zooming / long-press-menu while playing
    for (const el of [this.root, this.stick, this.act, this.runBtn]) el.addEventListener('contextmenu', (e) => e.preventDefault());
    this.stick.addEventListener('pointerdown', (e) => this.down(e));
    this.stick.addEventListener('pointermove', (e) => this.move(e));
    for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) this.stick.addEventListener(ev, (e) => this.up(e));
    this.act.addEventListener('pointerdown', (e) => { e.preventDefault(); this.act.setPointerCapture(e.pointerId); this.act.classList.add('down'); this.onInteract?.(); });
    for (const ev of ['pointerup', 'pointercancel']) this.act.addEventListener(ev, () => this.act.classList.remove('down'));
    this.runPtr = null;
    this.runBtn.addEventListener('pointerdown', (e) => { e.preventDefault(); this.runBtn.setPointerCapture(e.pointerId); this.runPtr = e.pointerId; this.run = true; this.runBtn.classList.add('down'); });
    for (const ev of ['pointerup', 'pointercancel']) this.runBtn.addEventListener(ev, (e) => { if (e.pointerId === this.runPtr) { this.run = false; this.runPtr = null; this.runBtn.classList.remove('down'); } });
    this.block = (e) => { if (e.touches && e.touches.length > 1) e.preventDefault(); };
    document.addEventListener('touchmove', this.preventScroll = (e) => { if (e.target.closest?.('.tc')) e.preventDefault(); }, { passive: false });
  }
  down(e) {
    if (this.stickPtr != null) return;
    e.preventDefault(); this.stickPtr = e.pointerId; this.stick.setPointerCapture(e.pointerId); this.stick.classList.add('active'); this.move(e);
  }
  move(e) {
    if (e.pointerId !== this.stickPtr) return;
    const r = this.stick.getBoundingClientRect(), R = r.width / 2;
    let dx = e.clientX - (r.left + R), dy = e.clientY - (r.top + R);
    const len = Math.hypot(dx, dy), max = R * 0.9;
    if (len > max) { dx = (dx / len) * max; dy = (dy / len) * max; }
    this.knob.style.transform = `translate(${dx}px, ${dy}px)`;
    const nx = dx / max, ny = dy / max, mag = Math.hypot(nx, ny);
    this.vector = mag < DEAD ? { x: 0, y: 0 } : { x: nx / Math.max(1, mag), y: ny / Math.max(1, mag) };
  }
  up(e) {
    if (e.pointerId !== this.stickPtr) return;
    this.stickPtr = null; this.vector = { x: 0, y: 0 };                   // release = stop immediately
    this.knob.style.transform = 'translate(0,0)'; this.stick.classList.remove('active');
  }
  setVisible(v) { this.root.hidden = !v; }
  destroy() { document.removeEventListener('touchmove', this.preventScroll); this.root.remove(); }
}
