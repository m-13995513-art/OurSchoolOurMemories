// Audience panel: every player in the auditorium sees (and can answer) the running PPT game.
import { h, clear, ICON } from './dom.js';
import { drawWheel, wheelAngle } from './wheel.js';

export class GamePanel {
  constructor(state) {
    this.state = state; this.dismissed = -1;
    this.root = h('div', { class: 'gp', id: 'gamepanel', hidden: true, role: 'region', 'aria-label': 'Game' });
    document.body.append(this.root);
    state.subscribe((k) => { if (k === 'game' || k === 'welcome' || k === 'players') this.render(); });
    this.timer = setInterval(() => this.tick && this.tick(), 200);
    this.key = (e) => {
      if (this.root.hidden || /INPUT|TEXTAREA/.test(document.activeElement?.tagName || '')) return;
      const i = '1234'.indexOf(e.key);
      if (i >= 0) this.answer(i);
    };
    window.addEventListener('keydown', this.key);
    this.render();
  }
  answer(i) {
    const g = this.state.game;
    if (g.phase !== 'question' || this.state.myChoice != null) return;
    this.state.myChoice = i; this.state.cmd('answer', { choice: i }); this.render();
  }
  render() {
    const g = this.state.game, s = this.state;
    cancelAnimationFrame(this.raf); this.tick = null;
    if (!g.type || g.phase === 'idle' || this.dismissed === g.updatedAt) { this.root.hidden = true; return; }
    this.root.hidden = false; clear(this.root);
    const x = h('button', { class: 'gp-x', html: ICON.close, 'aria-label': 'Hide', onClick: () => { this.dismissed = g.updatedAt; this.root.hidden = true; } });
    if (['quiz', 'tf', 'picture'].includes(g.type)) {
      const q = g.question, t = h('span', { class: 't' });
      const label = { quiz: 'QUIZ', tf: 'TRUE OR FALSE', picture: 'GUESS THE PICTURE' }[g.type];
      this.root.append(x, h('div', { class: 'gp-top' }, label, h('span', {}, `Q${g.qIndex + 1}/${g.total}`), t));
      let img;
      if (q?.image) { img = h('img', { class: 'gp-img', src: q.image, alt: '' }); this.root.append(img); }
      this.root.append(h('div', { class: 'gp-q' }, q?.q ?? ''));
      const mine = s.myChoice;
      this.root.append(h('div', { class: 'gp-opts' }, ...(q?.options ?? []).map((o, i) => {
        const cls = [mine === i ? 'mine' : '', q.correct === i ? 'right' : '', q.correct != null && mine === i && q.correct !== i ? 'wrong' : ''].join(' ');
        return h('button', { class: cls, 'data-choice': i, disabled: g.phase !== 'question' || mine != null, onClick: () => this.answer(i) }, `${i + 1}. ${o}`);
      })));
      if (g.phase === 'reveal') this.root.append(h('div', { class: 'gp-top' }, mine == null ? 'No answer' : mine === q.correct ? 'Correct!' : 'Not this time'));
      if (g.scores?.length && g.phase !== 'question') this.root.append(h('div', { class: 'ac-board' }, ...g.scores.slice(0, 5).map((r, i) => h('div', {}, `${i + 1}. ${r.nick}`, h('b', {}, r.score)))));
      this.tick = () => {
        const total = g.seconds * 1000, left = Math.max(0, g.deadline - s.serverNow);
        t.textContent = g.phase === 'question' ? Math.ceil(left / 1000) + 's' : '';
        if (img) img.style.filter = g.phase === 'question' ? `blur(${Math.round(18 * (left / total))}px)` : 'none';
      };
      this.tick();
    } else if (g.type === 'wheel') {
      const cv = h('canvas', { width: 420, height: 420 }), res = h('div', { class: 'gp-q', style: { textAlign: 'center' } });
      this.root.append(x, h('div', { class: 'gp-top' }, 'SPIN WHEEL'), h('div', { class: 'gp-wheel' }, cv, res));
      const loop = () => { drawWheel(cv, g.entries, wheelAngle(g, s.serverNow), g.phase === 'result' ? g.resultIndex : null); res.textContent = g.phase === 'result' ? '🎉 ' + g.entries[g.resultIndex] : g.phase === 'spinning' ? '…' : 'Waiting for the spin'; if (cv.isConnected) this.raf = requestAnimationFrame(loop); };
      loop();
    } else if (g.type === 'challenge') {
      const clock = h('span', { class: 't' });
      this.root.append(x, h('div', { class: 'gp-top' }, 'CLASSROOM CHALLENGE', clock),
        h('div', { class: 'ac-teams' }, ...g.teams.map((tm) => h('div', { class: 'ac-team' }, h('strong', {}, tm.name), h('div', { class: 'score' }, tm.score)))));
      this.tick = () => { const sec = Math.max(0, Math.ceil((g.endsAt - s.serverNow) / 1000)); clock.textContent = g.running ? `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}` : ''; };
      this.tick();
    }
  }
  destroy() { clearInterval(this.timer); cancelAnimationFrame(this.raf); window.removeEventListener('keydown', this.key); this.root.remove(); }
}
