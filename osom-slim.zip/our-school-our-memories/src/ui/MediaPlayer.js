// MEDIA PLAYER (Computer B) — separate from AUDITORIUMC on purpose: own window, own look, own state.
import { h, clear, ICON, fmtTime } from './dom.js';

const MAX = 80 * 1024 * 1024;
const ERR = { not_at_computer: 'Stand in front of this computer to control it.', computer_in_use: 'Someone else is using this computer.', bad_item: 'That file could not be added.', playlist_full: 'The playlist is full (12 items).' };

export class MediaPlayerUI {
  constructor(state, sync, { onClose } = {}) {
    this.state = state; this.sync = sync; this.onClose = onClose; this.busy = ''; this.note = '';
    this.build();
    this.unsub = state.subscribe((k) => { if (this.root.hidden) return; if (k === 'media' || k === 'welcome') this.render(); if (k === 'error') this.flash(ERR[state.lastError] ?? 'Error: ' + state.lastError); });
    this.timer = setInterval(() => this.tick(), 250);
  }
  build() {
    this.screen = h('div', { class: 'mp-screen', id: 'mp-screen' });
    this.list = h('div', { class: 'mp-list', id: 'mp-list' });
    this.seek = h('input', { type: 'range', min: 0, max: 1000, value: 0, id: 'mp-seek', 'aria-label': 'Seek', onChange: () => this.onSeek() });
    this.tcur = h('span', {}, '0:00'); this.tdur = h('span', {}, '0:00');
    this.vol = h('input', { type: 'range', min: 0, max: 100, value: 80, id: 'mp-vol', 'aria-label': 'Volume', onChange: () => this.state.media_('volume', { volume: this.vol.value / 100 }) });
    this.notice = h('div', { class: 'mp-note', id: 'mp-note', role: 'status' });
    this.playBtn = h('button', { class: 'mp-btn big', id: 'mp-play', 'aria-label': 'Play / Pause', onClick: () => this.togglePlay() });
    const btn = (ic, label, fn, id) => h('button', { class: 'mp-btn', html: ICON[ic], title: label, 'aria-label': label, id, onClick: fn });
    this.file = h('input', { type: 'file', accept: '.mp3,.mp4,audio/mpeg,video/mp4', hidden: true, id: 'mp-file', onChange: () => this.upload(this.file.files[0]) });
    this.root = h('div', { class: 'osom-overlay', role: 'dialog', 'aria-label': 'Media Player', id: 'mediaplayer' },
      h('div', { class: 'mp' },
        h('div', { class: 'mp-head' }, h('i', { html: ICON.music }), h('span', {}, 'MEDIA PLAYER'), h('span', { class: 'sp' }), h('button', { class: 'mp-x', html: ICON.close, 'aria-label': 'Close', id: 'mp-close', onClick: () => this.close() })),
        this.screen,
        h('div', { class: 'mp-side' },
          h('div', { class: 'mp-note' }, 'Playlist'), this.list,
          h('button', { class: 'mp-up', id: 'mp-upload', onClick: () => this.file.click() }, h('span', { html: ICON.upload }), 'Add MP3 / MP4'), this.file, this.notice),
        h('div', { class: 'mp-bar' },
          h('div', { class: 'mp-seek' }, this.tcur, this.seek, this.tdur),
          h('div', { class: 'mp-ctl' }, btn('prev', 'Previous', () => this.state.media_('prev'), 'mp-prev'), this.playBtn, btn('stop', 'Stop', () => this.state.media_('stop'), 'mp-stop'), btn('next', 'Next', () => this.state.media_('next'), 'mp-next'),
            h('div', { class: 'mp-vol' }, h('span', { html: ICON.vol }), this.vol), btn('full', 'Full screen', () => this.screen.requestFullscreen?.(), 'mp-full')))));
    this.keyHandler = (e) => { if (!this.root.hidden && e.key === 'Escape') { e.stopPropagation(); this.close(); } };
    window.addEventListener('keydown', this.keyHandler, true);
    this.render();
  }
  open() { document.body.append(this.root); this.root.hidden = false; this.render(); }
  close() { this.root.hidden = true; this.root.remove(); this.state.media_('release'); this.onClose?.(); }
  destroy() { clearInterval(this.timer); this.unsub?.(); window.removeEventListener('keydown', this.keyHandler, true); this.root.remove(); }
  flash(msg) { this.notice.textContent = msg; clearTimeout(this._ft); this._ft = setTimeout(() => (this.notice.textContent = this.busy), 3000); }

  togglePlay() {
    const m = this.state.media;
    this.sync.enable();                                   // this click is the user gesture browsers require for sound
    this.state.media_(m.isPlaying ? 'pause' : 'play');
  }
  onSeek() { const d = this.sync.el.duration; if (d && isFinite(d)) this.state.media_('seek', { position: (this.seek.value / 1000) * d }); }

  render() {
    const m = this.state.media, it = m.items[m.index];
    clear(this.list);
    if (!m.items.length) this.list.append(h('div', { class: 'mp-empty' }, 'Playlist is empty. Add an MP3 or MP4 file you are allowed to play.'));
    m.items.forEach((x, i) => this.list.append(h('button', { class: 'mp-item' + (i === m.index ? ' on' : ''), 'data-item': i, onClick: () => { this.sync.enable(); this.state.media_('select', { index: i }); } },
      h('span', { html: x.kind === 'video' ? ICON.slides : ICON.music }), h('span', {}, x.name), h('small', {}, x.kind.toUpperCase()))));
    clear(this.screen);
    if (it?.kind === 'video') this.screen.append(this.sync.el);
    else this.screen.append(h('div', { class: 'mp-art' }, h('div', { class: 'disc' + (m.isPlaying ? ' spin' : ''), html: ICON.music }), h('div', {}, it ? it.name : 'Nothing playing')));
    this.playBtn.innerHTML = m.isPlaying ? ICON.pause : ICON.play;
    this.playBtn.disabled = !m.items.length;
    if (document.activeElement !== this.vol) this.vol.value = Math.round(m.volume * 100);
  }
  tick() {
    if (this.root.hidden) return;
    const d = this.sync.el.duration, pos = this.state.mediaPosition();
    this.tcur.textContent = fmtTime(pos); this.tdur.textContent = d && isFinite(d) ? fmtTime(d) : '--:--';
    if (d && isFinite(d) && document.activeElement !== this.seek) this.seek.value = Math.min(1000, (pos / d) * 1000);
  }

  async upload(f) {
    if (!f) return;
    const okExt = /\.(mp3|mp4)$/i.test(f.name);
    if (!okExt) return this.flash('Only MP3 and MP4 files are supported.');
    if (f.size > MAX) return this.flash('That file is larger than 80 MB.');
    this.busy = 'Uploading…'; this.notice.textContent = this.busy;
    try {
      const r = await fetch(this.sync.httpBase + '/api/upload', { method: 'POST', body: f });
      if (!r.ok) throw new Error(r.status === 415 ? 'This is not a real MP3/MP4 file.' : 'Upload failed (' + r.status + ').');
      const j = await r.json();
      this.state.media_('add', { item: { ...j, name: f.name.replace(/\.[^.]+$/, '') } });
      this.busy = ''; this.flash('Added to playlist');
    } catch (e) { this.busy = ''; this.flash(e.message || 'Upload failed'); }
    this.file.value = '';
  }
}
