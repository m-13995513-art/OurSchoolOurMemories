import Phaser from 'phaser';
import './ui/ui.css';
import { GAME_W, GAME_H, COLORS } from './config/settings.js';
import { PreloadScene } from './scenes/PreloadScene.js';
import { MainMenuScene } from './scenes/MainMenuScene.js';
import { CharacterSelectScene } from './scenes/CharacterSelectScene.js';
import { AuditoriumScene } from './scenes/AuditoriumScene.js';
import { PauseScene } from './scenes/PauseScene.js';

new Phaser.Game({
  type: Phaser.AUTO, parent: 'game', width: GAME_W, height: GAME_H, backgroundColor: COLORS.navy,
  pixelArt: true, roundPixels: true,
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
  input: { activePointers: 4 },
  scene: [PreloadScene, MainMenuScene, CharacterSelectScene, AuditoriumScene, PauseScene],
});
