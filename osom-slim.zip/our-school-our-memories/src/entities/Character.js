// A player / NPC sprite with name tag. Animation keys come from public/assets/characters/animations.json.
import { SPRITE_SCALE, FONT } from '../config/settings.js';

const DIR = { up: 'back', down: 'front', left: 'left', right: 'right' };

export function createCharacterAnims(scene, animsJson) {
  for (const gender of ['male', 'female']) {
    for (const [name, a] of Object.entries(animsJson.anims[gender])) {
      const key = `${gender}_${name}`;
      if (scene.anims.exists(key)) continue;
      scene.anims.create({ key, frames: Array.from({ length: a.count }, (_, i) => ({ key: gender, frame: `${name}_${i}` })), frameRate: a.fps, repeat: a.loop ? -1 : 0 });
    }
  }
}

export class Character {
  constructor(scene, { gender = 'male', nick = '', x = 0, y = 0, me = false } = {}) {
    this.scene = scene; this.gender = gender; this.me = me;
    this.shadow = scene.add.ellipse(x, y, 20, 8, 0x000000, 0.28);
    this.sprite = scene.add.sprite(x, y, gender, 'front_idle_0').setOrigin(0.5, 0.95).setScale(SPRITE_SCALE);
    this.label = scene.add.text(x, y - 56, nick, { fontFamily: FONT, fontSize: '7px', color: me ? '#fde68a' : '#ffffff', stroke: '#101a33', strokeThickness: 3 }).setOrigin(0.5, 1).setResolution(2);
    this.bubble = null;
    this.dir = 'down'; this.anim = 'idle'; this.x = x; this.y = y;
    this.play('down', 'idle');
  }
  setNick(n) { this.label.setText(n); }
  /** dir: up|down|left|right (server names); anim: idle|walk|run|sit|interact */
  play(dir, anim) {
    if (dir === this.dir && anim === this.anim && this.sprite.anims.currentAnim) return;
    this.dir = dir; this.anim = anim;
    const side = DIR[dir];
    let name = `${side}_${anim}`;
    if (anim === 'sit' || anim === 'interact') name = `${anim}_${side}`;
    const key = `${this.gender}_${name}`;
    if (!this.scene.anims.exists(key)) return;
    if (anim === 'interact') this.sprite.play(key).once('animationcomplete', () => { if (this.anim === 'interact') this.play(this.dir, 'idle'); });
    else this.sprite.play(key, true);
  }
  setPos(x, y) {
    this.x = x; this.y = y;
    this.sprite.setPosition(x, y); this.shadow.setPosition(x, y - 1);
    this.label.setPosition(x, y - 50);
    const d = Math.round(y);
    this.shadow.setDepth(d - 1); this.sprite.setDepth(d); this.label.setDepth(d + 600);
    if (this.bubble) this.bubble.setPosition(x, y - 60).setDepth(d + 700);
  }
  say(text, ms = 3200) {
    this.bubble?.destroy();
    this.bubble = this.scene.add.text(this.x, this.y - 60, text, { fontFamily: FONT, fontSize: '6px', color: '#101a33', backgroundColor: '#fff8e7', padding: { x: 5, y: 4 }, wordWrap: { width: 140 }, align: 'center' }).setOrigin(0.5, 1).setResolution(2);
    this.scene.time.delayedCall(ms, () => { this.bubble?.destroy(); this.bubble = null; });
  }
  setVisible(v) { this.sprite.setVisible(v); this.shadow.setVisible(v); this.label.setVisible(v); this.bubble?.setVisible(v); }
  destroy() { this.sprite.destroy(); this.shadow.destroy(); this.label.destroy(); this.bubble?.destroy(); }
}
