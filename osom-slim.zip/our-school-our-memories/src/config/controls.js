// Keyboard map (desktop). Touch controls live in src/ui/MobileControls.js.
export const KEYS = {
  up: ['W', 'UP'], down: ['S', 'DOWN'], left: ['A', 'LEFT'], right: ['D', 'RIGHT'],
  run: ['SHIFT'], interact: ['E', 'SPACE'], pause: ['ESC'], mute: ['M'], emoteWave: ['G'],
};
