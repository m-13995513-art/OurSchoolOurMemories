// One place for gameplay constants. Movement numbers MUST match server/roomLogic.js (server validates them).
export { RUN_SPEED, SIT_RANGE, COMPUTER_RANGE, DOOR_RANGE, COMPUTER_ASSIGNMENT, isSolid } from '../../server/roomLogic.js';
export const WALK_SPEED = 110;
export const SPRITE_SCALE = 0.5;       // 128x120 frames -> 64x60 on screen before camera zoom
export const CAMERA_ZOOM = 2;
export const GAME_W = 1280;
export const GAME_H = 720;
export const SEND_MS = 100;            // move packets at 10 Hz (server TICK_MS)
export const SCENE_KEYS = { auditorium: 'floor1', auditorium_2f: 'floor2' };
export const COLORS = { navy: 0x101a33, blue: 0x3b82f6, sky: 0x7dd3fc, gold: 0xfcd34d, cream: 0xfff8e7, pink: 0xf9a8d4 };
export const FONT = '"Press Start 2P", "Courier New", monospace';
