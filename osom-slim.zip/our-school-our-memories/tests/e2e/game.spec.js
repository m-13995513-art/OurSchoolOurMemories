// STATUS: written, NEVER RUN (Phaser could not be installed in the authoring sandbox).
import { test, expect } from '@playwright/test';

const enter = async (page, nick) => {
  await page.goto('/');
  await page.waitForTimeout(1500);
  await page.mouse.click(640, 400);                       // START
  await page.waitForTimeout(500);
  await page.fill('input[placeholder="Your nickname"]', nick);
  await page.keyboard.press('Enter');
  await page.waitForSelector('#hud', { timeout: 15000 });
};

test('menu -> character select -> auditorium, HUD shows location', async ({ page }) => {
  await enter(page, 'Alice');
  await expect(page.locator('#hud')).toContainText('Auditorium 1F');
});

test('two browsers see each other', async ({ browser }) => {
  const a = await (await browser.newContext()).newPage(), b = await (await browser.newContext()).newPage();
  await enter(a, 'Alice'); await enter(b, 'Bob');
  await expect(a.locator('#hud')).toContainText('2', { timeout: 10000 });
});

test('keyboard movement does not crash and stays connected', async ({ page }) => {
  await enter(page, 'Walker');
  await page.keyboard.down('ArrowLeft'); await page.waitForTimeout(800); await page.keyboard.up('ArrowLeft');
  await expect(page.locator('#hud')).toContainText('Auditorium');
});
