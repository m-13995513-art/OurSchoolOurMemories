// Run: node --test tests/
import test from 'node:test';
import assert from 'node:assert/strict';
import { makeRoom, PNG, C1, C2 } from './helpers.js';
import { AUDITORIUM } from '../src/maps/auditoriumMap.js';
import { isSolid } from '../server/roomLogic.js';

const door = (id) => AUDITORIUM.doors.find((d) => d.id === id);
const centre = (d) => [d.zone[0] + d.zone[2] / 2, d.zone[1] + d.zone[3] / 2];

// ------------------------------------------------------------------ joining
test('two players join, see each other, and leaving cleans up', () => {
  const h = makeRoom();
  h.join('a'); h.join('b');
  assert.equal(h.last('b', 'welcome').players.length, 2);
  assert.equal(h.last('a', 'join').p.id, 'b');
  h.room.leave('b');
  assert.equal(h.last('a', 'leave').id, 'b');
  assert.equal(h.room.players.size, 1);
});

test('room refuses the 25th player', () => {
  const h = makeRoom();
  for (let i = 0; i < 24; i++) h.join('p' + i);
  h.join('late');
  assert.equal(h.last('late', 'error').code, 'room_full');
});

test('nickname is sanitised, gender falls back safely', () => {
  const h = makeRoom();
  const p = h.join('a', { nick: '<b>Amy</b>\n', gender: 'robot' });
  assert.equal(p.nick, 'bAmy/b');
  assert.equal(p.gender, 'male');
});

// ------------------------------------------------------------------ movement validation
test('legal walking is accepted and broadcast with direction + animation', () => {
  const h = makeRoom(); h.join('a'); h.join('b'); h.clear();
  h.walk('a', [[600, 840]]);
  h.room.tick();
  const snap = h.last('b', 'snap');
  const me = snap.p.find((p) => p.id === 'a');
  assert.equal(Math.round(me.x), 600);
  assert.equal(me.dir, 'left'); assert.equal(me.anim, 'walk');
  assert.equal(h.all('a', 'correct').length, 0);
});

test('teleporting is rejected and the player is corrected', () => {
  const h = makeRoom(); h.join('a'); h.clear();
  h.advance(100);
  h.send('a', { t: 'move', x: 100, y: 100, dir: 'up', anim: 'walk', scene: 'auditorium' });
  assert.equal(h.last('a', 'correct').reason, 'move');
  assert.ok(Math.abs(h.room.players.get('a').x - AUDITORIUM.spawn.x) < 1);
});

test('walking into a wall or a seat block is rejected', () => {
  const h = makeRoom(); h.join('a');
  h.walk('a', [[640, 700]]);
  h.clear(); h.advance(100);
  const before = { ...h.room.players.get('a') };
  h.send('a', { t: 'move', x: before.x - 14, y: before.y, dir: 'left', anim: 'walk', scene: 'auditorium' });
  assert.ok(!h.last('a', 'correct'));                                        // aisle is open
  assert.ok(isSolid('auditorium', 300, 500));                                // inside the yellow block
  assert.ok(isSolid('auditorium', 640, 40));                                 // top wall
  assert.ok(!isSolid('auditorium', 640, 700));                               // red carpet
});

test('malformed move messages are ignored', () => {
  const h = makeRoom(); h.join('a'); h.clear(); h.advance(100);
  for (const bad of [{ t: 'move' }, { t: 'move', x: 'a', y: 1, dir: 'up', anim: 'walk', scene: 'auditorium' }, { t: 'move', x: 600, y: 840, dir: 'sideways', anim: 'walk', scene: 'auditorium' }, { t: 'move', x: NaN, y: 1, dir: 'up', anim: 'walk', scene: 'auditorium' }, null, 5, { t: 99 }]) {
    assert.doesNotThrow(() => h.room.handle('a', bad));
  }
  assert.equal(h.room.players.get('a').x, AUDITORIUM.spawn.x);
});

test('message flood is throttled', () => {
  const h = makeRoom(); h.join('a'); h.clear();
  for (let i = 0; i < 200; i++) h.send('a', { t: 'ping', c: i });
  assert.ok(h.all('a', 'pong').length <= 40);
});

// ------------------------------------------------------------------ doors / 2nd floor
test('both stage side doors lead to the 2nd floor and back to the matching door', () => {
  for (const [id, back, spawn] of [['stage_door_left', 'stairs_down_left', 'stairs_left'], ['stage_door_right', 'stairs_down_right', 'stairs_right']]) {
    const h = makeRoom(); h.join('a'); h.join('b');
    const d = door(id);
    h.walk('a', [[640, 700], [640, 270], [640, 262], [d.zone[0] + d.zone[2] / 2, 262], centre(d)]);
    h.clear();
    h.send('a', { t: 'interact', id });
    const c = h.last('a', 'correct');
    assert.equal(c.scene, 'auditorium_2f'); assert.equal(c.reason, 'door');
    assert.deepEqual([c.x, c.y], [AUDITORIUM.floor2.spawns[spawn].x, AUDITORIUM.floor2.spawns[spawn].y]);
    h.room.tick();
    assert.equal(h.last('b', 'snap').p.find((p) => p.id === 'a').scene, 'auditorium_2f');
    // back down
    const down = AUDITORIUM.floor2.doors.find((x) => x.id === back);
    h.walk('a', [[down.zone[0] + down.zone[2] / 2, down.zone[1] + down.zone[3] / 2]], 'auditorium_2f');
    h.send('a', { t: 'interact', id: back });
    assert.equal(h.last('a', 'correct').scene, 'auditorium');
  }
});

test('door too far away is refused; rear exit is NOT an upstairs door', () => {
  const h = makeRoom(); h.join('a'); h.clear();
  h.send('a', { t: 'interact', id: 'stage_door_left' });
  assert.equal(h.last('a', 'correct').reason, 'too_far');
  assert.equal(AUDITORIUM.doors.find((d) => d.id === 'rear_exit').kind, 'exit');
  h.walk('a', [[640, 880]]);
  h.clear(); h.send('a', { t: 'interact', id: 'rear_exit' });
  assert.equal(h.last('a', 'interact').kind, 'exit_blocked');
  assert.equal(h.room.players.get('a').scene, 'auditorium');
});

test('scene cannot be changed by a move message', () => {
  const h = makeRoom(); h.join('a'); h.clear(); h.advance(100);
  h.send('a', { t: 'move', x: AUDITORIUM.spawn.x, y: AUDITORIUM.spawn.y, dir: 'up', anim: 'idle', scene: 'auditorium_2f' });
  assert.equal(h.last('a', 'correct').reason, 'scene');
});

// ------------------------------------------------------------------ seats
test('sit, taken seat, hop to the neighbour, stand up on a walkable tile', () => {
  const h = makeRoom(); h.join('a'); h.join('b');
  const seat = AUDITORIUM.seats.find((s) => s.id === 'RR_L_2_12');             // rear red row, next to the open walkway
  const nxt = AUDITORIUM.seats.find((s) => s.id === 'RR_L_2_11');
  h.walk('a', [[640, 840], [seat.x + 28, 780], [seat.x + 28, seat.y + 18]]);
  h.walk('b', [[640, 840]]);
  h.clear();
  h.send('a', { t: 'sit', seatId: seat.id });
  assert.equal(h.last('a', 'seat').ok, true);
  h.send('b', { t: 'sit', seatId: seat.id });
  assert.equal(h.last('b', 'seat').why, 'taken');                               // occupied seats are refused
  h.send('b', { t: 'sit', seatId: 'Y_L_5_5' });                                 // a free seat that is too far away
  assert.equal(h.last('b', 'seat').why, 'far');
  h.send('a', { t: 'sit', seatId: nxt.id });                                    // hop sideways while seated
  assert.equal(h.room.players.get('a').seatId, nxt.id);
  assert.ok(!h.room.occupied.has(seat.id));
  h.send('a', { t: 'stand' });
  const p = h.room.players.get('a');
  assert.equal(p.seatId, null);
  assert.ok(!isSolid('auditorium', p.x, p.y), 'standing point must be walkable');
  h.send('a', { t: 'move', x: p.x + 5, y: p.y, dir: 'left', anim: 'walk', scene: 'auditorium' });   // can move again
});

test('a seated player cannot walk; leaving frees the seat', () => {
  const h = makeRoom(); h.join('a');
  const seat = AUDITORIUM.seats.find((s) => s.id === 'RR_L_2_12');
  h.walk('a', [[640, 840], [seat.x + 28, 780], [seat.x + 28, seat.y + 18]]);
  h.send('a', { t: 'sit', seatId: seat.id });
  h.advance(100); const x = h.room.players.get('a').x;
  h.send('a', { t: 'move', x: x + 5, y: seat.y, dir: 'right', anim: 'walk', scene: 'auditorium' });
  assert.equal(h.room.players.get('a').x, x);
  h.room.leave('a');
  assert.ok(!h.room.occupied.has(seat.id));
});

// ------------------------------------------------------------------ presentation: ONE state for four screens
test('PPT controls require standing at computer 1', () => {
  const h = makeRoom(); h.join('a'); h.clear();
  h.send('a', { t: 'ppt', action: 'load', title: 'x', slides: [PNG] });
  assert.equal(h.last('a', 'error').code, 'not_at_computer');
  h.toComputer('a', C2);                                                        // the media computer must not control slides
  h.clear(); h.send('a', { t: 'ppt', action: 'load', title: 'x', slides: [PNG] });
  assert.equal(h.last('a', 'error').code, 'not_at_computer');
});

test('slide changes reach every player as the same presentation state', () => {
  const h = makeRoom(); h.join('a'); h.join('b'); h.join('c');
  h.toComputer('a', C1); h.clear();
  h.send('a', { t: 'ppt', action: 'load', title: 'Graduation', slides: [PNG, PNG, PNG, PNG] });
  const id = h.room.ppt.presentationId;
  for (const who of ['a', 'b', 'c']) {
    const s = h.last(who, 'ppt').state;
    assert.equal(s.presentationId, id); assert.equal(s.totalSlides, 4); assert.equal(s.currentSlide, 0);
  }
  h.advance(50); h.send('a', { t: 'ppt', action: 'next' }); h.send('a', { t: 'ppt', action: 'next' });
  h.advance(50); h.send('a', { t: 'ppt', action: 'play' });
  for (const who of ['a', 'b', 'c']) { const s = h.last(who, 'ppt').state; assert.equal(s.currentSlide, 2); assert.equal(s.isPlaying, true); }
  h.send('a', { t: 'ppt', action: 'pause' });
  assert.equal(h.last('b', 'ppt').state.isPlaying, false);
  h.send('a', { t: 'ppt', action: 'goto', index: 99 });
  assert.equal(h.last('c', 'ppt').state.currentSlide, 3);                        // clamped
  h.send('a', { t: 'ppt', action: 'next' });
  const end = h.last('b', 'ppt').state;
  assert.equal(end.ended, true); assert.equal(end.isPlaying, false);
  assert.ok(end.updatedAt > 0);
});

test('slide images are served on request, bad images are refused', () => {
  const h = makeRoom(); h.join('a'); h.join('b'); h.toComputer('a', C1);
  h.send('a', { t: 'ppt', action: 'load', title: 't', slides: ['data:text/html;base64,AAAA'] });
  assert.equal(h.last('a', 'error').code, 'slide_invalid');
  h.send('a', { t: 'ppt', action: 'load', title: 't', slides: Array(41).fill(PNG) });
  assert.equal(h.last('a', 'error').code, 'slides_count');
  h.send('a', { t: 'ppt', action: 'load', title: 't', slides: [PNG, PNG] });
  h.clear();
  h.send('b', { t: 'getSlide', presentationId: h.room.ppt.presentationId, index: 1 });
  assert.equal(h.last('b', 'slide').data, PNG);
  h.send('b', { t: 'getSlide', presentationId: 'nope', index: 0 });
  assert.equal(h.all('b', 'slide').length, 1);
});

test('only one controller at a time; takeover after they walk away', () => {
  const h = makeRoom(); h.join('a'); h.join('b');
  h.toComputer('a', C1); h.toComputer('b', C1);
  h.clear();
  h.send('a', { t: 'ppt', action: 'load', title: 't', slides: [PNG] });
  h.send('b', { t: 'ppt', action: 'play' });
  assert.equal(h.last('b', 'error').code, 'computer_in_use');
  h.walk('a', [[500, 840], [640, 840]]);
  h.send('b', { t: 'ppt', action: 'play' });
  assert.equal(h.room.ppt.controllerId, 'b');
});

test('late joiners and reconnecting clients get the current slide immediately', () => {
  const h = makeRoom(); h.join('a', { clientId: 'cA' }); h.toComputer('a', C1);
  h.send('a', { t: 'ppt', action: 'load', title: 'Deck', slides: [PNG, PNG, PNG] });
  h.send('a', { t: 'ppt', action: 'goto', index: 2 });
  h.join('late');
  assert.equal(h.last('late', 'welcome').ppt.currentSlide, 2);
  // connection drops and the same browser returns on a new socket
  const pos = { ...h.room.players.get('a') };
  h.join('a2', { clientId: 'cA' });
  const w = h.last('a2', 'welcome');
  assert.equal(w.resumed, true);
  assert.equal(w.ppt.currentSlide, 2);
  assert.ok(Math.abs(h.room.players.get('a2').x - pos.x) < 0.01);
  assert.ok(!h.room.players.has('a'));
});

test('My Files: you can delete your own upload, never someone else\'s', () => {
  const h = makeRoom(); h.join('a', { clientId: 'cA' }); h.join('b', { clientId: 'cB' });
  h.toComputer('a', C1);
  h.send('a', { t: 'ppt', action: 'load', title: 'Mine', slides: [PNG] });
  const id = h.room.ppt.presentationId;
  assert.equal(h.last('a', 'files').files[0].mine, true);
  assert.equal(h.last('b', 'files').files[0].mine, false);
  assert.ok(!JSON.stringify(h.last('b', 'files')).includes('cA'), 'clientId must never be sent to other players');
  h.send('b', { t: 'fileDelete', id });
  assert.equal(h.last('b', 'error').code, 'not_yours');
  assert.equal(h.room.files.length, 1);
  h.send('a', { t: 'fileDelete', id });
  assert.equal(h.room.files.length, 0);
  assert.equal(h.last('b', 'ppt').state.presentationId, null);
  h.send('a', { t: 'fileDelete', id: 'system-asset' });                        // system assets are not in the list at all
  assert.equal(h.last('a', 'error').code, 'not_yours');
});

// ------------------------------------------------------------------ media player: independent from slides
test('media state is separate from slides and positions stay consistent', () => {
  const h = makeRoom(); h.join('a'); h.join('b');
  h.toComputer('a', C2);
  const url = '/media/' + '0123abcd-0123-4abc-8abc-0123456789ab';
  h.clear();
  h.send('a', { t: 'media', action: 'add', item: { url, kind: 'audio', name: 'Song', bytes: 10 } });
  h.send('a', { t: 'media', action: 'add', item: { url: 'http://evil.example/x.mp3', kind: 'audio', name: 'x' } });
  assert.equal(h.last('a', 'error').code, 'bad_item');
  h.send('a', { t: 'media', action: 'play' });
  const s0 = h.last('b', 'media').state;
  assert.equal(s0.isPlaying, true); assert.equal(s0.items.length, 1);
  h.advance(5000);
  h.send('a', { t: 'media', action: 'pause' });
  assert.ok(Math.abs(h.last('b', 'media').state.position - 5) < 0.01);
  h.send('a', { t: 'media', action: 'seek', position: 42 });
  assert.equal(h.last('b', 'media').state.position, 42);
  h.send('a', { t: 'media', action: 'volume', volume: 7 });
  assert.equal(h.last('b', 'media').state.volume, 1);
  assert.equal(h.room.ppt.presentationId, null);
  h.toComputer('b', C1);                                                         // computer 1 cannot drive the media player
  h.send('b', { t: 'media', action: 'play' });
  assert.equal(h.last('b', 'error').code, 'not_at_computer');
});

// ------------------------------------------------------------------ mini games
const QS = [{ q: '2+2?', options: ['3', '4', '5', '6'], correct: 1 }, { q: 'Sky colour?', options: ['Blue', 'Green'], correct: 0 }];

test('quiz: server scores answers, one answer per player, reveal hides nothing early', () => {
  const h = makeRoom(); h.join('a'); h.join('b'); h.toComputer('a', C1);
  h.clear();
  h.send('a', { t: 'game', action: 'start', type: 'quiz', questions: QS, seconds: 20 });
  const st = h.last('b', 'game').state;
  assert.equal(st.phase, 'question'); assert.equal(st.question.correct, null, 'correct answer must not leak before reveal');
  h.advance(2000);
  h.send('a', { t: 'answer', choice: 1 });
  h.send('a', { t: 'answer', choice: 0 });                                       // second answer ignored
  assert.equal(h.room.game.answers['a'].choice, 1);
  h.advance(1000);
  h.send('b', { t: 'answer', choice: 3 });                                       // wrong, last player -> auto reveal
  const rv = h.last('a', 'game').state;
  assert.equal(rv.phase, 'reveal'); assert.equal(rv.question.correct, 1);
  assert.deepEqual(rv.counts, [0, 1, 0, 1]);
  const lb = rv.scores;
  assert.equal(lb[0].nick, 'a'); assert.ok(lb[0].score >= 100 && lb[0].score <= 150);
  h.send('a', { t: 'game', action: 'next' });
  h.send('a', { t: 'game', action: 'next' });                                    // ignored: still question 2
  assert.equal(h.last('b', 'game').state.qIndex, 1);
});

test('quiz: question ends by itself when the timer runs out', () => {
  const h = makeRoom(); h.join('a'); h.toComputer('a', C1);
  h.send('a', { t: 'game', action: 'start', type: 'tf', questions: [{ q: 'Is water wet?', correct: 0 }], seconds: 10 });
  h.advance(10_500); h.room.tickTimers();
  assert.equal(h.room.game.phase, 'reveal');
  h.send('a', { t: 'game', action: 'next' });
  assert.equal(h.room.game.phase, 'done');
});

test('spin wheel result is decided by the server and identical for everyone', () => {
  const h = makeRoom(); h.join('a'); h.join('b'); h.toComputer('a', C1);
  h.send('a', { t: 'game', action: 'start', type: 'wheel', entries: ['Amy', 'Ben', 'Cara'] });
  h.send('a', { t: 'game', action: 'spin' });
  const s = h.last('b', 'game').state;
  assert.equal(s.phase, 'spinning'); assert.equal(s.resultIndex, null);
  h.advance(5000); h.room.tickTimers();
  const r1 = h.last('a', 'game').state, r2 = h.last('b', 'game').state;
  assert.equal(r1.phase, 'result'); assert.equal(r1.resultIndex, r2.resultIndex);
  assert.ok(r1.resultIndex >= 0 && r1.resultIndex < 3);
});

test('classroom challenge: team points and timer', () => {
  const h = makeRoom(); h.join('a'); h.toComputer('a', C1);
  h.send('a', { t: 'game', action: 'start', type: 'challenge', seconds: 30 });
  h.send('a', { t: 'game', action: 'points', team: 2, delta: 10 });
  h.send('a', { t: 'game', action: 'points', team: 2, delta: 9999 });            // clamped
  assert.equal(h.last('a', 'game').state.teams[2].score, 60);
  h.send('a', { t: 'game', action: 'timer', run: true });
  assert.equal(h.last('a', 'game').state.running, true);
  h.advance(31_000); h.room.tickTimers();
  assert.equal(h.last('a', 'game').state.running, false);
});

test('only the person at computer 1 can run games; audience cannot start or reveal', () => {
  const h = makeRoom(); h.join('a'); h.join('b'); h.toComputer('a', C1); h.clear();
  h.send('b', { t: 'game', action: 'start', type: 'quiz', questions: QS });
  assert.equal(h.last('b', 'error').code, 'not_at_computer');
  assert.equal(h.room.game.type, null);
});
