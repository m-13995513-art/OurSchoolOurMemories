// Real sockets + real timers against server/dev-server.js (same Room logic the Durable Object uses).
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import WebSocket from 'ws';
import { createDevServer } from '../server/dev-server.js';
import { AUDITORIUM } from '../src/maps/auditoriumMap.js';

const PNG = 'data:image/png;base64,iVBORw0KGgo=';
const C1 = AUDITORIUM.computers[0];
let srv, base;
before(async () => { srv = await createDevServer({ port: 0 }); base = `localhost:${srv.port}`; });
after(async () => { await srv.close(); });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class Client {
  constructor(room, hello) { this.room = room; this.hello = hello; this.msgs = []; this.pos = null; }
  async open() {
    this.ws = new WebSocket(`ws://${base}/ws?room=${this.room}`);
    this.ws.on('message', (d) => { const m = JSON.parse(d.toString()); this.msgs.push(m); if (m.t === 'correct') this.pos = { x: m.x, y: m.y }; });
    await new Promise((r) => this.ws.once('open', r));
    this.ws.send(JSON.stringify({ t: 'hello', ...this.hello }));
    this.welcome = await this.wait((m) => m.t === 'welcome');
    const me = this.welcome.players.find((p) => p.id === this.welcome.id);
    this.pos ??= { x: me.x, y: me.y };
    return this;
  }
  send(m) { this.ws.send(JSON.stringify(m)); }
  async wait(fn, ms = 3000) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) { const m = this.msgs.find(fn); if (m) return m; await sleep(15); }
    throw new Error('timeout waiting for message; got ' + this.msgs.map((m) => m.t).join(','));
  }
  last(type) { return [...this.msgs].reverse().find((m) => m.t === type); }
  async walk(pts, scene = 'auditorium') {
    for (const [tx, ty] of pts) {
      for (let g = 0; g < 300; g++) {
        const d = Math.hypot(tx - this.pos.x, ty - this.pos.y);
        if (d < 0.5) break;
        const k = Math.min(1, 17 / d);
        this.pos = { x: this.pos.x + (tx - this.pos.x) * k, y: this.pos.y + (ty - this.pos.y) * k };
        this.send({ t: 'move', ...this.pos, dir: 'left', anim: 'walk', scene });
        await sleep(100);
      }
    }
  }
  close() { this.ws.close(); }
}

test('two real browsers-worth of clients: join, see each other, positions and directions sync', async () => {
  const a = await new Client('t1', { nick: 'Amy', gender: 'female', clientId: 'cli-a' }).open();
  const b = await new Client('t1', { nick: 'Ben', gender: 'male', clientId: 'cli-b' }).open();
  assert.equal(b.welcome.players.length, 2);
  assert.equal((await a.wait((m) => m.t === 'join')).p.nick, 'Ben');
  await a.walk([[600, 840], [560, 840]]);
  const seen = await b.wait((m) => m.t === 'snap' && m.p.some((p) => p.id === a.welcome.id && Math.abs(p.x - 560) < 1));
  const pa = seen.p.find((p) => p.id === a.welcome.id);
  assert.equal(pa.dir, 'left'); assert.equal(pa.anim, 'walk'); assert.equal(pa.gender, 'female');
  a.close();
  assert.equal((await b.wait((m) => m.t === 'leave')).id, a.welcome.id);       // disconnect detected + cleaned up
  b.close();
});

test('PPT page change is received by every client, late joiner gets the page, slide data fetchable', async () => {
  const a = await new Client('t2', { nick: 'Teacher', clientId: 'cli-t' }).open();
  const b = await new Client('t2', { nick: 'Student', clientId: 'cli-s' }).open();
  await a.walk([[640, 840], [500, 840], [C1.x, 846]]);
  a.send({ t: 'ppt', action: 'load', title: 'Our Memories', slides: [PNG, PNG, PNG] });
  const first = await b.wait((m) => m.t === 'ppt');
  assert.equal(first.state.totalSlides, 3);
  a.send({ t: 'ppt', action: 'next' });
  const moved = await b.wait((m) => m.t === 'ppt' && m.state.currentSlide === 1);
  assert.equal(moved.state.presentationId, first.state.presentationId);
  b.send({ t: 'getSlide', presentationId: first.state.presentationId, index: 1 });
  assert.equal((await b.wait((m) => m.t === 'slide')).data, PNG);
  const c = await new Client('t2', { nick: 'Late', clientId: 'cli-l' }).open();
  assert.equal(c.welcome.ppt.currentSlide, 1);
  assert.equal(c.welcome.ppt.presentationId, first.state.presentationId);
  [a, b, c].forEach((x) => x.close());
});

test('disconnect then automatic reconnect: same place, same slide', async () => {
  const a = await new Client('t3', { nick: 'Amy', clientId: 'cli-re' }).open();
  await a.walk([[640, 840], [500, 840], [C1.x, 846]]);
  a.send({ t: 'ppt', action: 'load', title: 'R', slides: [PNG, PNG] });
  await a.wait((m) => m.t === 'ppt');
  a.send({ t: 'ppt', action: 'next' });
  await a.wait((m) => m.t === 'ppt' && m.state.currentSlide === 1);
  const before = { ...a.pos };
  a.ws.terminate();                                                            // network drop, no clean close
  await sleep(200);
  const a2 = await new Client('t3', { nick: 'Amy', clientId: 'cli-re' }).open();
  assert.equal(a2.welcome.resumed, true);
  assert.equal(a2.welcome.ppt.currentSlide, 1);
  const me = a2.welcome.players.find((p) => p.id === a2.welcome.id);
  assert.ok(Math.hypot(me.x - before.x, me.y - before.y) < 1);
  assert.equal(a2.welcome.players.length, 1, 'no ghost of the old connection');
  a2.close();
});

test('media upload: real MP3/MP4 accepted, other bytes rejected, range requests work', async () => {
  const mp3 = Buffer.concat([Buffer.from('ID3\x03\x00\x00\x00\x00\x00\x00'), Buffer.alloc(4000, 7)]);
  const ok = await fetch(`http://${base}/api/upload`, { method: 'POST', body: mp3 });
  assert.equal(ok.status, 200);
  const j = await ok.json();
  assert.equal(j.kind, 'audio'); assert.match(j.url, /^\/media\/[a-f0-9-]{36}$/);
  const mp4 = Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypmp42'), Buffer.alloc(100)]);
  assert.equal((await (await fetch(`http://${base}/api/upload`, { method: 'POST', body: mp4 })).json()).kind, 'video');
  assert.equal((await fetch(`http://${base}/api/upload`, { method: 'POST', body: Buffer.from('<script>alert(1)</script>....') })).status, 415);
  assert.equal((await fetch(`http://${base}/api/upload`, { method: 'POST', body: Buffer.from('MZ\x90\x00 an exe renamed to .mp3 ......') })).status, 415);
  const part = await fetch(`http://${base}${j.url}`, { headers: { range: 'bytes=10-19' } });
  assert.equal(part.status, 206);
  assert.equal(part.headers.get('content-range'), `bytes 10-19/${mp3.length}`);
  assert.equal((await part.arrayBuffer()).byteLength, 10);
  assert.equal(part.headers.get('content-type'), 'audio/mpeg');
});

test('media playlist state is shared in real time', async () => {
  const a = await new Client('t4', { nick: 'DJ', clientId: 'cli-dj' }).open();
  const b = await new Client('t4', { nick: 'Fan', clientId: 'cli-fan' }).open();
  const up = await (await fetch(`http://${base}/api/upload`, { method: 'POST', body: Buffer.concat([Buffer.from('ID3\x03\x00\x00\x00\x00\x00\x00'), Buffer.alloc(500)]) })).json();
  await a.walk([[640, 840], [500, 840], [AUDITORIUM.computers[1].x, 846]]);
  a.send({ t: 'media', action: 'add', item: { ...up, name: 'Graduation Song' } });
  a.send({ t: 'media', action: 'play' });
  const st = (await b.wait((m) => m.t === 'media' && m.state.isPlaying)).state;
  assert.equal(st.items[0].name, 'Graduation Song'); assert.equal(st.items[0].url, up.url);
  a.close(); b.close();
});
