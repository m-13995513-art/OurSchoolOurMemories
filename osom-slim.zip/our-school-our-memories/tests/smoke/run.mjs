// Scene-logic smoke test: real AuditoriumScene code + fake Phaser + REAL server + real Chrome.
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import { createRequire } from 'node:module'; import { fileURLToPath } from 'node:url';
import { createDevServer } from '../../server/dev-server.js';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const req = createRequire(import.meta.url);
let pw; try { pw = req('playwright'); } catch { pw = createRequire('/home/claude/.npm-global/lib/node_modules/')('playwright'); }
const MIME = { '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.html': 'text/html' };
const game = await createDevServer({ port: 0 });
const web = http.createServer((q, s) => { const p = path.join(ROOT, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (!p.startsWith(ROOT) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { s.writeHead(404); return s.end(); } s.writeHead(200, { 'content-type': MIME[path.extname(p)] ?? 'application/octet-stream' }); fs.createReadStream(p).pipe(s); });
await new Promise((r) => web.listen(0, r));
const browser = await pw.chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true, args: ['--no-sandbox'] });
const results = []; const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m}: expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); }; const ok = (v, m) => { if (!v) throw new Error(m); };
const test = async (n, f) => { try { await f(); results.push([n, 'PASS']); console.log('PASS', n); } catch (e) { results.push([n, 'FAIL']); console.log('FAIL', n, '-', e.message.split('\n')[0]); } };
const open = async (nick) => { const p = await browser.newPage({ viewport: { width: 1280, height: 720 } }); p.errs = []; p.on('pageerror', (e) => p.errs.push(e.message)); await p.goto(`http://localhost:${web.address().port}/tests/smoke/smoke.html?port=${game.port}&nick=${nick}`); await p.waitForFunction(() => window.sm?.ready(), null, { timeout: 8000 }); return p; };
const A = await open('Alice'), B = await open('Bob');

await test('scene boots and joins the real server (no page errors)', async () => { eq(A.errs, [], 'errors'); eq(await A.evaluate(() => sm.sc.state.players.size), 2, 'players'); });
await test('holding left moves the player and the server agrees', async () => {
  const p = await A.evaluate(() => sm.frames(12, ['LEFT'])); ok(p.x < 620, 'moved left ' + p.x);
  await A.waitForTimeout(400); const s = await B.evaluate(() => { const o = [...sm.sc.state.players.values()].find((x) => x.nick === 'Alice'); return o.x; });
  ok(Math.abs(s - p.x) < 12, `server x ${s} vs client ${p.x}`);
  await B.evaluate(() => sm.frames(10)); ok((await B.evaluate(() => sm.sc.others.size)) === 1, 'Bob renders Alice');
});
await test('walls stop the player (no tunnelling out of the map)', async () => { const p = await A.evaluate(() => sm.frames(160, ['DOWN'])); ok(p.y < 900, 'blocked ' + p.y); });
await test('walk to a seat, sit via interact, hop, and stand', async () => {
  // fresh page so we start at the spawn
  const C = await open('Carol');
  await C.evaluate(() => sm.frames(30, ['UP', 'RIGHT']));
  const near = await C.evaluate(() => sm.sc.candidates().map((c) => c.kind + ':' + (c.seat?.id ?? '')));
  ok(near.some((k) => k.startsWith('sit')), 'a seat is offered: ' + near);
  await C.evaluate(() => sm.sc.interact()); await C.waitForFunction(() => sm.sc.seatId, null, { timeout: 3000 });
  const seat = await C.evaluate(() => sm.sc.seatId);
  await C.waitForTimeout(300); eq(await B.evaluate((id) => [...sm.sc.state.players.values()].some((p) => p.seat === id), seat), true, 'others see her seated');
  await C.evaluate(() => sm.sc.seatedHop('LEFT')); await C.waitForFunction((s) => sm.sc.seatId && sm.sc.seatId !== s, seat, { timeout: 3000 });
  await C.evaluate(() => sm.sc.interact()); await C.waitForFunction(() => !sm.sc.seatId, null, { timeout: 3000 });
  eq(C.errs, [], 'errors'); await C.close();
});
await test('exit door shows the NEEDS_REFERENCE message instead of a fake campus', async () => {
  const D = await open('Dave');
  await D.evaluate(() => sm.frames(120, ['DOWN']));
  const kinds = await D.evaluate(() => sm.sc.candidates().map((c) => c.kind));
  ok(kinds.includes('door'), 'exit door offered: ' + kinds);
  await D.evaluate(() => sm.sc.interact());
  await D.waitForFunction(() => /NEEDS_REFERENCE/.test(document.querySelector('#hud-toast')?.textContent || ''), null, { timeout: 3000 });
  eq(D.errs, [], 'errors'); await D.close();
});
await test('stage door -> 2F (server moves her), then stairs down -> 1F again', async () => {
  const E = await open('Erin');
  const r = await E.evaluate(() => sm.sc.scene_ && sm.goTo(110, 150)); ok(r !== 'no-path', 'path to stage-left door');
  const kinds = await E.evaluate(() => sm.sc.candidates().map((c) => c.kind + ':' + c.id)); ok(kinds.some((k) => k.startsWith('door:stage_door_left')), 'door offered: ' + kinds);
  await E.evaluate(() => sm.sc.interact());
  await E.waitForFunction(() => sm.sc.scene_ === 'auditorium_2f' && !sm.sc.transition, null, { timeout: 4000 });
  eq(await E.evaluate(() => sm.sc.candidates().map((c) => c.id).filter(Boolean)).then((a) => a.length >= 0), true, 'candidates work on 2F');
  await E.evaluate(() => sm.frames(5));
  await E.evaluate(() => sm.goTo(112, 150)); await E.evaluate(() => sm.frames(20, ['W']));
  const k2 = await E.evaluate(() => sm.sc.candidates().map((c) => c.id)); ok(k2.some((x) => /stairs_down/.test(x)), 'stairs down offered: ' + k2);
  await E.evaluate(() => sm.sc.interact());
  await E.waitForFunction(() => sm.sc.scene_ === 'auditorium' && !sm.sc.transition, null, { timeout: 4000 });
  eq(E.errs, [], 'errors'); await E.close();
});
await browser.close(); await game.close(); web.close();
const pass = results.filter((r) => r[1] === 'PASS').length; console.log(`\n${pass}/${results.length} passed`); process.exit(pass === results.length ? 0 : 1);
