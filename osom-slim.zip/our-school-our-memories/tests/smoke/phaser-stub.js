// Minimal fake of the parts of Phaser the scenes touch, so scene LOGIC can be exercised against the real server in real Chrome.
// It does NOT render anything and proves nothing about Phaser's own behaviour.
const Z = new Proxy(function () {}, { get: (t, k) => (k === Symbol.toPrimitive ? () => 0 : k === 'then' ? undefined : Z), apply: () => Z, set: () => true });
const key = () => ({ isDown: false });
class Scene {
  constructor(k) {
    this.sys = { key: k }; const calls = (this.calls = []);
    this.add = Z; this.tweens = Z; this.load = Z; this.cache = Z;
    this.cameras = { main: { setBounds() { return this; }, setZoom() { return this; }, startFollow() { return this; }, fadeIn() { return this; }, fadeOut() { calls.push('fadeOut'); return this; }, once(_e, cb) { cb(); } } };
    this.input = { on() {}, keyboard: { disableGlobalCapture() {}, addKeys: () => Object.fromEntries('W,A,S,D,UP,DOWN,LEFT,RIGHT,SHIFT,E,SPACE,ESC,M,G'.split(',').map((k) => [k, key()])), on() {}, once() {} } };
    this.anims = { exists: () => false, create() {} }; this.textures = { exists: () => false, addImage() {} };
    this.time = { delayedCall() {} }; this.scene = { launch() {}, pause() {}, stop() {}, start() {}, isPaused: () => false };
    this.game = { events: { on() {}, off() {}, emit() {} } }; this.events = { once() {} };
  }
}
export default { Scene, AUTO: 0, Scale: { FIT: 0, CENTER_BOTH: 0 }, Math: { Between: (a) => a } };
