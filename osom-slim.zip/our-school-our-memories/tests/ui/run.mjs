// Real Chrome UI tests (no Phaser needed): consoles, shared state, media sync, games, touch controls.
// Run: node tests/ui/run.mjs     (needs: playwright + system Chrome, ffmpeg for media fixtures)
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createDevServer } from '../../server/dev-server.js';
import { AUDITORIUM } from '../../src/maps/auditoriumMap.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const req = createRequire(import.meta.url);
let playwright;
try { playwright = req('playwright'); } catch { playwright = createRequire('/home/claude/.npm-global/lib/node_modules/')('playwright'); }
let PDFLib; try { PDFLib = req('pdf-lib'); } catch { PDFLib = createRequire('/home/claude/.npm-global/lib/node_modules/')('pdf-lib'); }

const SHOTS = path.join(ROOT, 'build', 'ui-shots'); fs.mkdirSync(SHOTS, { recursive: true });
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'osom-ui-'));
const MIME = { '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.html': 'text/html', '.png': 'image/png', '.json': 'application/json' };
const C1 = AUDITORIUM.computers[0], C2 = AUDITORIUM.computers[1];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------- fixtures
async function makePdf(file, n = 4) {
  const doc = await PDFLib.PDFDocument.create();
  const font = await doc.embedFont(PDFLib.StandardFonts.HelveticaBold);
  const cols = [[0.16, 0.48, 1], [1, 0.55, 0.65], [0.3, 0.75, 0.55], [1, 0.8, 0.3]];
  for (let i = 0; i < n; i++) {
    const pg = doc.addPage([960, 540]); const c = cols[i % 4];
    pg.drawRectangle({ x: 0, y: 0, width: 960, height: 540, color: PDFLib.rgb(...c) });
    pg.drawText(`Slide ${i + 1}`, { x: 300, y: 240, size: 90, font, color: PDFLib.rgb(1, 1, 1) });
  }
  fs.writeFileSync(file, await doc.save());
}
const ff = (...a) => execFileSync('ffmpeg', ['-y', '-loglevel', 'error', ...a]);
const PDF = path.join(TMP, 'Graduation.pdf'), MP3 = path.join(TMP, 'song.mp3'), MP4 = path.join(TMP, 'clip.mp4'), PPTX = path.join(TMP, 'deck.pptx');
await makePdf(PDF);
ff('-f', 'lavfi', '-i', 'sine=frequency=440:duration=20', '-codec:a', 'libmp3lame', '-b:a', '64k', MP3);
let haveMp4 = true;
try { ff('-f', 'lavfi', '-i', 'testsrc=size=320x180:rate=15:duration=20', '-f', 'lavfi', '-i', 'sine=frequency=330:duration=20', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', MP4); } catch { haveMp4 = false; }
fs.writeFileSync(PPTX, Buffer.concat([Buffer.from('PK\x03\x04'), Buffer.alloc(200)]));

// ---------------------------------------------------------------- servers + browser
const game = await createDevServer({ port: 0 });
const web = http.createServer((q, s) => {
  const u = new URL(q.url, 'http://x'); let p = path.join(ROOT, decodeURIComponent(u.pathname));
  if (!p.startsWith(ROOT) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { s.writeHead(404); return s.end(); }
  s.writeHead(200, { 'content-type': MIME[path.extname(p)] ?? 'application/octet-stream' }); fs.createReadStream(p).pipe(s);
});
await new Promise((r) => web.listen(0, r));
const WEB = `http://localhost:${web.address().port}`;
const browser = await playwright.chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true, args: ['--autoplay-policy=no-user-gesture-required'.replace('no-user-gesture-required', 'document-user-activation-required'), '--no-sandbox'] });

let roomN = 0;
const URLQ = (room, nick, cid) => `${WEB}/tests/ui/harness.html?port=${game.port}&room=${room}&nick=${nick}&cid=${cid}`;
async function client(ctx, room, nick, extra = {}) {
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => m.type() === 'error' && !/Failed to load resource/.test(m.text()) && errors.push(m.text()));
  page.on('response', (r) => r.status() >= 400 && !/favicon/.test(r.url()) && errors.push(r.status() + ' ' + r.url()));
  await page.goto(URLQ(room, nick, 'cid-' + nick + '-' + room));
  await page.waitForFunction(() => window.osom?.ready(), null, { timeout: 8000 });
  page.errors = errors; page.nick = nick;
  return page;
}
const goto = (page, c) => page.evaluate(async ([a, b]) => { await osom.walk([[640, 840], [500, 840], [a, b]]); }, [c.x, 846]);
const results = [];
async function test(name, fn) {
  const t0 = Date.now();
  try { await fn(); results.push({ name, status: 'PASS', ms: Date.now() - t0 }); console.log('PASS', name); }
  catch (e) { results.push({ name, status: 'FAIL', ms: Date.now() - t0, error: String(e.message).split('\n')[0] }); console.log('FAIL', name, '-', String(e.message).split('\n')[0], '\n   ', (e.stack.match(/run\.mjs:\d+/)||[''])[0]); }
}
const eq = (a, b, m = '') => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m} expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); };
const ok = (v, m) => { if (!v) throw new Error(m); };
const desktop = await browser.newContext({ viewport: { width: 1280, height: 800 } });

// ================================================================ tests
await test('AUDITORIUMC opens with the 4 tiles (PPT Player / PPT Games / Screen Sync / My Files)', async () => {
  const p = await client(desktop, 'r' + ++roomN, 'Teacher');
  await p.evaluate(() => osom.ac.open());
  eq(await p.locator('.ac-tile').count(), 4);
  eq(await p.locator('.ac-tile strong').allTextContents(), ['PPT Player', 'PPT Games', 'Screen Sync', 'My Files']);
  ok((await p.locator('.ac-title').textContent()).includes('PRESENTATION CONTROL CENTER'));
  ok((await p.locator('.ac-foot').textContent()).includes('4 Displays Connected'));
  await p.screenshot({ path: path.join(SHOTS, 'auditoriumc-home.png') });
  eq(p.errors, [], 'console errors');
});

const room1 = 'r' + ++roomN;
let T, S;
await test('PDF upload shows slides; all four simulated screens follow ONE state (next / pause / end)', async () => {
  T = await client(desktop, room1, 'Teacher'); S = await client(desktop, room1, 'Student');
  await goto(T, C1);
  await T.evaluate(() => osom.ac.open('ppt'));
  await T.setInputFiles('#ac-file', PDF);
  await S.waitForFunction(() => osom.state.ppt.totalSlides === 4, null, { timeout: 15000 });
  await S.waitForFunction(() => [...document.querySelectorAll('[data-sim]')].every((e) => e.dataset.slide === '0' && e.style.backgroundImage.startsWith('url')), null, { timeout: 8000 });
  await T.click('button[aria-label="Next slide"]'); await T.click('button[aria-label="Next slide"]');
  await S.waitForFunction(() => [...document.querySelectorAll('[data-sim]')].every((e) => e.dataset.slide === '2'), null, { timeout: 5000 });
  await T.click('#ac-play');
  await S.waitForFunction(() => [...document.querySelectorAll('[data-sim]')].every((e) => e.dataset.playing === 'true'));
  await T.click('#ac-play');
  await S.waitForFunction(() => [...document.querySelectorAll('[data-sim]')].every((e) => e.dataset.playing === 'false'));
  await T.evaluate(() => osom.state.ppt_('goto', { index: 1 }));
  await T.waitForFunction(() => osom.state.ppt.currentSlide === 1, null, { timeout: 5000 });
  await sleep(1200);

  await T.screenshot({ path: path.join(SHOTS, 'auditoriumc-ppt.png') });
  await T.click('button[aria-label="End presentation"]');
  await S.waitForFunction(() => [...document.querySelectorAll('[data-sim]')].every((e) => e.dataset.ended === 'true'));
  await T.click('button[aria-label="Previous slide"]');
  await S.waitForFunction(() => [...document.querySelectorAll('[data-sim]')].every((e) => e.dataset.slide === '0' && e.dataset.ended === 'false'));
});

await test('a player who is NOT at the computer cannot change the slides', async () => {
  await T.waitForFunction(() => osom.state.ppt.currentSlide === 0);
  const before = 0;
  await S.evaluate(() => osom.state.ppt_('goto', { index: 3 }));
  await S.waitForFunction(() => osom.state.lastError === 'not_at_computer', null, { timeout: 3000 });
  await sleep(400);
  eq(await T.evaluate(() => osom.state.ppt.currentSlide), before);
});

await test('Screen Sync page shows 4 screens with the shared state', async () => {
  await T.evaluate(() => osom.ac.go('sync'));
  eq(await T.locator('.ac-mon').count(), 4);
  const raw = JSON.parse(await T.locator('#ac-raw').textContent());
  eq(Object.keys(raw).sort(), ['currentSlide', 'isPlaying', 'presentationId', 'totalSlides', 'updatedAt']);
  eq(raw.totalSlides, 4);
  await T.screenshot({ path: path.join(SHOTS, 'auditoriumc-sync.png') });
});

await test('My Files: own upload deletable, other player cannot delete it', async () => {
  await T.evaluate(() => osom.ac.go('files')); await S.evaluate(() => osom.ac.open('files'));
  eq(await T.locator('.ac-file button.bad:not([disabled])').count(), 1);
  eq(await S.locator('.ac-file button.bad:not([disabled])').count(), 0);
  await S.evaluate(() => osom.state.cmd('fileDelete', { id: osom.state.files[0].id }));
  await S.waitForFunction(() => osom.state.lastError === 'not_yours');
  eq(await T.evaluate(() => osom.state.files.length), 1);
  await S.evaluate(() => osom.ac.close());
});

await test('PowerPoint (.pptx) is refused with a clear "save as PDF" message (not faked)', async () => {
  await T.evaluate(() => { osom.state.ppt_('unload'); osom.ac.go('ppt'); });
  await T.waitForSelector('#ac-file', { state: 'attached' });
  await T.setInputFiles('#ac-file', PPTX);
  await T.waitForSelector('.ac-err');
  ok((await T.locator('.ac-err').textContent()).includes('Save As'), 'message');
});

await test('late joiner sees the current slide; dropped connection reconnects and resumes', async () => {
  await T.evaluate(() => osom.state.ppt_('unload'));
  await T.setInputFiles('#ac-file', PDF);
  await T.waitForFunction(() => osom.state.ppt.totalSlides === 4, null, { timeout: 15000 });
  await T.click('button[aria-label="Next slide"]');
  await T.waitForFunction(() => osom.state.ppt.currentSlide === 1);
  const L = await client(desktop, room1, 'Late');
  await L.waitForFunction(() => osom.state.ppt.currentSlide === 1 && document.querySelector('[data-sim]').style.backgroundImage.startsWith('url'), null, { timeout: 8000 });
  const resumed = L.evaluate(() => new Promise((r) => osom.net.on('welcome', (m) => r(m.resumed))));
  await L.evaluate(() => osom.net.ws.close());                      // simulate a dropped socket
  eq(await resumed, true, 'resumed flag');
  eq(await L.evaluate(() => osom.state.ppt.currentSlide), 1);
  await L.close();
});

await test('Quiz: audience answers from their own screen, server reveals and scores', async () => {
  await T.evaluate(() => { osom.state.ppt_('unload'); osom.ac.open('games'); });
  await T.click('[data-game="quiz"]');
  await T.click('#ac-start');
  await S.waitForSelector('#gamepanel .gp-opts button', { state: 'visible' });
  eq((await S.locator('#gamepanel .gp-opts button').allTextContents()).length, 4);
  await S.screenshot({ path: path.join(SHOTS, 'game-quiz-audience.png') });
  await S.click('#gamepanel [data-choice="1"]');                    // 7×8 = 56 (correct)
  await T.waitForFunction(() => document.querySelector('#ac-answered')?.textContent.startsWith('1'), null, { timeout: 5000 });
  await T.click('#ac-reveal');
  await S.waitForSelector('#gamepanel button.right', { timeout: 5000 });
  ok((await S.locator('#gamepanel .ac-board').textContent()).includes('Student'), 'leaderboard');
  await T.screenshot({ path: path.join(SHOTS, 'game-quiz-console.png') });
  await T.click('#ac-next'); await S.waitForFunction(() => osom.state.game.qIndex === 1);
  await T.click('#ac-stop'); await S.waitForFunction(() => !osom.state.game.type);
});

await test('Spin wheel: identical result on both clients (decided by the server)', async () => {
  await T.evaluate(() => { osom.ac.open('games'); });
  await T.click('[data-game="wheel"]'); await T.click('#ac-start');
  await T.waitForSelector('#ac-spin'); await T.click('#ac-spin');
  await S.waitForFunction(() => osom.state.game.phase === 'result', null, { timeout: 9000 });
  await T.waitForFunction(() => osom.state.game.phase === 'result', null, { timeout: 3000 });
  const [a, b] = await Promise.all([T, S].map((p) => p.evaluate(() => osom.state.game.resultIndex)));
  eq(a, b); ok(a >= 0 && a < 5);
  await T.screenshot({ path: path.join(SHOTS, 'game-wheel.png') });
  await T.click('#ac-stop');
});

await test('Classroom challenge: team points reach the audience panel', async () => {
  await T.evaluate(() => osom.ac.open('games')); await T.click('[data-game="challenge"]'); await T.click('#ac-start');
  await T.click('.ac-team[data-team="0"] button:has-text("+5")');
  await S.waitForFunction(() => osom.state.game.teams?.[0].score === 5);
  ok((await S.locator('#gamepanel').textContent()).includes('Team A'));
  await T.click('#ac-stop');
});

await test('Media player: MP3 upload, play, pause, seek stay in sync on a second client', async () => {
  await T.evaluate(() => osom.ac.close());
  await goto(T, C2);                                                // slot 2 is the media computer
  await T.evaluate(() => osom.mp.open());
  await T.setInputFiles('#mp-file', MP3);
  await T.waitForFunction(() => osom.state.media.items.length === 1, null, { timeout: 8000 });
  await S.evaluate(() => osom.hud.showAudioButton(true));
  await S.click('#hud-audio');                                      // real click = the user gesture browsers require
  await T.click('#mp-play');
  await S.waitForFunction(() => !osom.sync.el.paused && osom.sync.el.currentTime > 1.2, null, { timeout: 12000 });
  const [tp, sp] = await Promise.all([T, S].map((p) => p.evaluate(() => osom.sync.el.currentTime)));
  ok(Math.abs(tp - sp) < 1.5, `drift ${tp} vs ${sp}`);
  await T.click('#mp-play');
  await S.waitForFunction(() => osom.sync.el.paused, null, { timeout: 4000 });
  await T.evaluate(() => osom.state.media_('seek', { position: 12 }));
  await S.waitForFunction(() => Math.abs(osom.sync.el.currentTime - 12) < 1, null, { timeout: 4000 });
  await T.screenshot({ path: path.join(SHOTS, 'mediaplayer.png') });
  ok((await T.locator('.ac').count()) === 0, 'media player is a separate window from AUDITORIUMC');
});

await test('Media player: MP4 video decodes in Chrome' + (haveMp4 ? '' : ' (no ffmpeg h264 here)'), async () => {
  ok(haveMp4, 'could not create an MP4 fixture');
  await T.setInputFiles('#mp-file', MP4);
  await T.waitForFunction(() => osom.state.media.items.length === 2, null, { timeout: 8000 });
  await T.click('.mp-item[data-item="1"]');
  await T.waitForFunction(() => osom.sync.el.videoWidth > 0, null, { timeout: 10000 });
  await T.screenshot({ path: path.join(SHOTS, 'mediaplayer-video.png') });
});

await test('Media files: only real MP3/MP4 bytes are accepted by the server', async () => {
  const fake = path.join(TMP, 'evil.mp3'); fs.writeFileSync(fake, 'MZ this is not audio ........ padding');
  await T.setInputFiles('#mp-file', fake);
  await T.waitForFunction(() => document.querySelector('#mp-note').textContent.includes('not a real'), null, { timeout: 5000 });
  eq(await T.evaluate(() => osom.state.media.items.length), 2);
});

// ---------------------------------------------------------------- phone / tablet
const phone = await browser.newContext({ viewport: { width: 915, height: 412 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2.6, userAgent: 'Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 Chrome/153 Mobile Safari/537.36' });
let M;
await test('MOBILE (emulated Pixel 7 landscape): joystick, interact and run work together with 3 fingers; release stops', async () => {
  M = await client(phone, 'r' + ++roomN, 'Phone');
  await M.evaluate(() => { window.__interacts = 0; osom.mc.setVisible(true); });
  const box = async (sel) => { const b = await M.locator(sel).boundingBox(); return { x: b.x + b.width / 2, y: b.y + b.height / 2 }; };
  const stick = await box('#tc-stick'), act = await box('#tc-act'), run = await box('#tc-run');
  ok(stick.x < 200 && stick.y > 200, 'stick bottom-left'); ok(act.x > 700 && act.y > 250, 'interact bottom-right');
  const cdp = await phone.newCDPSession(M);
  const touch = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map(([x, y, id]) => ({ x, y, id })) });
  await touch('touchStart', [[stick.x, stick.y, 1]]);
  await touch('touchMove', [[stick.x + 45, stick.y - 10, 1]]);
  let v = await M.evaluate(() => osom.mc.vector);
  ok(v.x > 0.6 && Math.abs(v.y) < 0.4, 'stick right ' + JSON.stringify(v));
  await touch('touchStart', [[stick.x + 45, stick.y - 10, 1], [act.x, act.y, 2]]);          // second finger: interact while moving
  await touch('touchStart', [[stick.x + 45, stick.y - 10, 1], [act.x, act.y, 2], [run.x, run.y, 3]]);   // third finger: run
  ok((await M.evaluate(() => window.__interacts)) === 1, 'interact fired once');
  ok(await M.evaluate(() => osom.mc.run), 'run held');
  v = await M.evaluate(() => osom.mc.vector); ok(v.x > 0.6, 'still moving while other fingers are down');
  await touch('touchEnd', [[run.x, run.y, 3]]); ok(!(await M.evaluate(() => osom.mc.run)), 'run released');
  await touch('touchEnd', [[act.x, act.y, 2]]);
  await touch('touchEnd', [[stick.x + 45, stick.y - 10, 1]]);
  eq(await M.evaluate(() => osom.mc.vector), { x: 0, y: 0 }, 'stops immediately on release');
  eq(await M.evaluate(() => document.scrollingElement.scrollTop), 0, 'page did not scroll');
  await M.screenshot({ path: path.join(SHOTS, 'mobile-hud.png') });
});

await test('MOBILE: AUDITORIUMC and Media Player fit a landscape phone screen', async () => {
  for (const [open, sel] of [['osom.ac.open()', '.ac'], ['osom.ac.close(); osom.mp.open()', '.mp']]) {
    await M.evaluate(open);
    const b = await M.locator(sel).boundingBox();
    ok(b.x >= -1 && b.y >= -1 && b.x + b.width <= 916 && b.y + b.height <= 413, `${sel} fits: ${JSON.stringify(b)}`);
    await M.screenshot({ path: path.join(SHOTS, `mobile-${sel.slice(1)}.png`) });
  }
  await M.evaluate(() => osom.mp.close());
});

const tablet = await browser.newContext({ viewport: { width: 1280, height: 800 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
await test('TABLET (emulated 1280×800): touch controls visible, console usable', async () => {
  const P = await client(tablet, 'r' + ++roomN, 'Tab');
  ok(await P.locator('#tc').isVisible(), 'touch controls shown on touch devices');
  await P.evaluate(() => osom.ac.open());
  await P.tap('.ac-tile[data-tile="games"]');
  eq(await P.locator('.ac-card.game').count(), 5);
  await P.screenshot({ path: path.join(SHOTS, 'tablet-games.png') });
});

await test('DESKTOP: touch controls are hidden for mouse + keyboard users', async () => {
  const P = await client(desktop, 'r' + ++roomN, 'Desk');
  ok(!(await P.locator('#tc').isVisible()), 'hidden');
});

await browser.close(); await game.close(); web.close();
const pass = results.filter((r) => r.status === 'PASS').length;
fs.writeFileSync(path.join(ROOT, 'build', 'ui-test-results.json'), JSON.stringify(results, null, 1));
console.log(`\n${pass}/${results.length} passed`);
process.exit(pass === results.length ? 0 : 1);
