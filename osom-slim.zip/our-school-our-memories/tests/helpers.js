import { Room } from '../server/roomLogic.js';
import { AUDITORIUM } from '../src/maps/auditoriumMap.js';

export const PNG = 'data:image/png;base64,iVBORw0KGgo=';
export const C1 = AUDITORIUM.computers[0], C2 = AUDITORIUM.computers[1];

/** Room driven by a fake clock; every outbound message is recorded per connection. */
export function makeRoom() {
  const clock = { t: 1_000_000 };
  const inbox = new Map();
  const log = (cid) => { if (!inbox.has(cid)) inbox.set(cid, []); return inbox.get(cid); };
  const room = new Room({
    send: (cid, m) => log(cid).push(m),
    broadcast: (m, except) => { for (const cid of room.players.keys()) if (cid !== except) log(cid).push(m); },
    now: () => clock.t,
  });
  const api = {
    room, clock, inbox,
    join(cid, extra = {}) { log(cid); return room.join(cid, { t: 'hello', nick: cid, gender: 'male', ...extra }); },
    last(cid, type) { return [...log(cid)].reverse().find((m) => m.t === type); },
    all(cid, type) { return log(cid).filter((m) => m.t === type); },
    clear() { inbox.forEach((v) => v.splice(0)); },
    send(cid, m) { room.handle(cid, m); },
    advance(ms) { clock.t += ms; },
    /** legal walking: 100 ms ticks, 14 px per tick (140 px/s, below the 190 px/s run limit) */
    walk(cid, pts, scene = 'auditorium') {
      for (const [tx, ty] of pts) {
        for (let guard = 0; guard < 400; guard++) {
          const p = room.players.get(cid);
          const d = Math.hypot(tx - p.x, ty - p.y);
          if (d < 0.5) break;
          const k = Math.min(1, 14 / d);
          api.advance(100);
          api.send(cid, { t: 'move', x: p.x + (tx - p.x) * k, y: p.y + (ty - p.y) * k, dir: 'left', anim: 'walk', scene });
        }
      }
    },
    toComputer(cid, c) { api.walk(cid, [[640, 840], [500, 840], [c.x, 846]]); },
  };
  return api;
}
