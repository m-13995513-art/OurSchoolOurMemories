// Shared by the browser client AND the server (Worker / Durable Object / dev server).
// Keep this file dependency-free.

export const PROTOCOL_VERSION = 1;
export const MAX_PLAYERS = 24;
export const TICK_MS = 100;                 // server broadcasts positions at 10 Hz
export const MAX_MSG_BYTES = 8 * 1024 * 1024;   // slide uploads travel as one message
export const LIMITS = Object.freeze({
  nick: 16, slides: 40, slideBytes: 700 * 1024, totalSlideBytes: 14 * 1024 * 1024,
  title: 60, question: 140, option: 60, files: 12, mediaItems: 12,
});

export const SCENES = Object.freeze({ F1: 'auditorium', F2: 'auditorium_2f' });
export const DIRS = Object.freeze(['up', 'down', 'left', 'right']);
export const ANIMS = Object.freeze(['idle', 'walk', 'run', 'sit', 'interact']);

// client -> server
export const C2S = Object.freeze({
  HELLO: 'hello', MOVE: 'move', INTERACT: 'interact', SIT: 'sit', STAND: 'stand', EMOTE: 'emote',
  PPT: 'ppt', MEDIA: 'media', GAME: 'game', ANSWER: 'answer', GET_SLIDE: 'getSlide', PING: 'ping', FILE_DELETE: 'fileDelete',
});
// server -> client
export const S2C = Object.freeze({
  WELCOME: 'welcome', JOIN: 'join', LEAVE: 'leave', SNAP: 'snap', CORRECT: 'correct', PPT: 'ppt', MEDIA: 'media',
  GAME: 'game', SLIDE: 'slide', INTERACT: 'interact', SEAT: 'seat', ERROR: 'error', PONG: 'pong', FILES: 'files',
});

export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
export const cleanText = (s, max) => String(s ?? '').replace(/[\u0000-\u001f\u007f<>]/g, '').trim().slice(0, max);

export function validateMove(m) {
  return m && isNum(m.x) && isNum(m.y) && DIRS.includes(m.dir) && ANIMS.includes(m.anim) &&
    (m.scene === SCENES.F1 || m.scene === SCENES.F2) && Math.abs(m.x) < 1e5 && Math.abs(m.y) < 1e5;
}

export const dataUrlOk = (u) => typeof u === 'string' && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(u);
